'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { PRODUCTS, TRANSLATIONS } from '@/lib/translations';
import { Language, Product } from '@/types';
import { ShieldCheck, CheckCircle2, ArrowUpRight, X, Sparkles, FileText, ArrowRight, ArrowLeft } from 'lucide-react';

interface ProductSectionProps {
  lang: Language;
  isDark: boolean;
  onSelectProductForInquiry: (product: Product) => void;
}

export function ProductSection({
  lang,
  isDark,
  onSelectProductForInquiry,
}: ProductSectionProps) {
  const [activeFilter, setActiveFilter] = useState<'all' | 'analog' | 'digital' | 'preowned'>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const t = TRANSLATIONS[lang];

  // Prevent background scroll and allow Escape key dismissal when modal is active
  useEffect(() => {
    if (selectedProduct) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';

      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          setSelectedProduct(null);
        }
      };

      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = originalOverflow;
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [selectedProduct]);

  const filteredProducts = PRODUCTS.filter((p) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'analog') return p.type === 'analog';
    if (activeFilter === 'digital') return p.type === 'digital';
    if (activeFilter === 'preowned') return p.condition === 'preowned';
    return true;
  });

  const formatPrice = (priceTomans: number, priceUsd: number) => {
    if (lang === 'fa') {
      return (
        <div className="flex flex-col">
          <div className="text-xl font-bold text-[#ee2524] tracking-tight">
            {priceTomans.toLocaleString('fa-IR')}{' '}
            <span className="text-xs font-normal text-[#999999]">تومان</span>
          </div>
          <div className="text-[11px] font-mono text-[#999999]">
            معادل تقریبی: ${priceUsd.toLocaleString()}
          </div>
        </div>
      );
    }
    return (
      <div className="flex flex-col">
        <div className="text-xl font-bold text-[#ee2524] tracking-tight">
          ${priceUsd.toLocaleString()}{' '}
          <span className="text-xs font-normal text-[#999999]">USD</span>
        </div>
        <div className="text-[11px] font-mono text-[#999999]">
          Approx. {priceTomans.toLocaleString()} Tomans
        </div>
      </div>
    );
  };

  return (
    <section
      id="products"
      className={`py-28 relative z-10 transition-colors duration-300 overflow-hidden border-y backdrop-blur-[2px] ${
        isDark
          ? 'bg-neutral-950/20 border-white/10 text-white shadow-[inset_0_1px_1px_0_rgba(255,255,255,0.08),inset_0_-1px_1px_0_rgba(255,255,255,0.04),0_20px_40px_rgba(0,0,0,0.3)]'
          : 'bg-white/30 border-neutral-300/50 text-[#0D0D0D] shadow-[inset_0_1px_1px_0_rgba(255,255,255,0.6),inset_0_-1px_1px_0_rgba(0,0,0,0.02),0_16px_32px_rgba(0,0,0,0.02)]'
      }`}
    >
      {/* Precision CAD Optical Grid Background for Equipment Showcase - Visible through Glass */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        {/* Glass Sheen / Specular Light Reflection Layer */}
        <div
          className={`absolute inset-0 pointer-events-none ${
            isDark
              ? 'bg-gradient-to-b from-white/[0.04] via-transparent to-black/20'
              : 'bg-gradient-to-b from-white/40 via-transparent to-neutral-200/20'
          }`}
        />

        {/* Diagonal Glass Prism Glare */}
        <div
          className="absolute -top-40 -left-40 w-96 h-[140%] -rotate-45 pointer-events-none opacity-20 blur-2xl"
          style={{
            background: isDark
              ? 'linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent)'
              : 'linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent)',
          }}
        />

        {/* Rich atmospheric studio optical glows */}
        <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-[#ee2524]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-[#ee2524]/8 rounded-full blur-3xl pointer-events-none" />

        {/* Technical Grid Pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-65" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="products-grid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path
                d="M 48 0 L 0 0 0 48"
                fill="none"
                stroke={isDark ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.09)'}
                strokeWidth="0.8"
              />
              <circle
                cx="48"
                cy="48"
                r="1"
                fill="#ee2524"
                opacity={isDark ? 0.5 : 0.4}
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#products-grid)" />
        </svg>

        {/* Top/Bottom Optical Ruler Tape */}
        <div className="absolute top-2 inset-x-0 flex justify-between px-8 text-[9px] font-mono opacity-50 text-neutral-500">
          <span>{`// 35MM / 120 FORMAT ARCHIVE`}</span>
          <span>CALIBRATED TO SIRANG LAB STANDARDS</span>
          <span>{`OPTICAL BENCH #02 //`}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight mb-4">
              {t.productsTitle}
            </h2>
            <p className={`text-base leading-relaxed ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
              {t.productsSubtitle}
            </p>
          </div>

          {/* Filter Pills with Glassmorphism */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: t.filterAll },
              { id: 'analog', label: t.filterAnalog },
              { id: 'digital', label: t.filterDigital },
              { id: 'preowned', label: t.filterPreowned },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-200 cursor-pointer backdrop-blur-xs ${
                  activeFilter === tab.id
                    ? 'bg-[#ee2524] text-white shadow-md shadow-[#ee2524]/20'
                    : isDark
                    ? 'bg-gradient-to-b from-neutral-800/35 via-neutral-900/15 to-transparent border border-white/10 text-neutral-300 hover:border-white/20'
                    : 'bg-gradient-to-b from-white/70 via-neutral-100/25 to-transparent border border-neutral-300/40 text-neutral-700 hover:border-neutral-400 shadow-xs'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid with Gray-to-Transparent Glassmorphism */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
              const conditionText = lang === 'fa' ? product.conditionFa : product.conditionEn;
              const title = lang === 'fa' ? product.name : product.nameEn;
              const badge = lang === 'fa' ? product.badgeFa : product.badgeEn;
              const specs = lang === 'fa' ? product.specsFa : product.specsEn;

              return (
                <div
                  key={product.id}
                  className={`group rounded-2xl border flex flex-col overflow-hidden transition-all duration-300 hover:shadow-xl backdrop-blur-xs ${
                    isDark
                      ? 'bg-gradient-to-b from-neutral-800/45 via-neutral-900/20 to-transparent border-white/15 hover:border-white/30 text-white shadow-black/40'
                      : 'bg-gradient-to-b from-white/80 via-neutral-100/35 to-transparent border-neutral-300/50 hover:border-neutral-400 text-[#0D0D0D] shadow-neutral-300/30 shadow-sm'
                  }`}
                >
                  {/* Image Container with WebP format */}
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-950/40">
                    <Image
                      src={product.image}
                      alt={title}
                      fill
                      className="object-cover object-center transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                    />

                    {/* Badge top-left */}
                    {badge && (
                      <div className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded-md text-[11px] font-semibold bg-[#ee2524] text-white shadow-md">
                        {badge}
                      </div>
                    )}

                    {/* Condition Tag top-right */}
                    <div className="absolute top-3 right-3 z-10 px-2.5 py-1 rounded-md text-[11px] font-mono backdrop-blur-md bg-black/60 text-white border border-white/10">
                      {product.type === 'analog' ? 'ANALOG' : 'DIGITAL'}
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Condition label */}
                      <div className="flex items-center gap-1.5 text-xs text-[#ee2524] font-medium mb-1.5">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{conditionText}</span>
                      </div>

                      {/* Product Name */}
                      <h3 className="font-bold text-base md:text-lg mb-2 line-clamp-1 group-hover:text-[#ee2524] transition-colors">
                        {title}
                      </h3>

                      {/* Diagnostic Summary */}
                      <p className={`text-xs line-clamp-2 mb-4 ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                        {lang === 'fa' ? product.diagnosticInfoFa : product.diagnosticInfoEn}
                      </p>

                      {/* Highlights / Specs bullets */}
                      <ul className="space-y-1.5 mb-5 text-[11px]">
                        {specs.slice(0, 2).map((item, specIdx) => (
                          <li key={specIdx} className="flex items-start gap-2">
                            <CheckCircle2 className="w-3 h-3 text-[#ee2524] shrink-0 mt-0.5" />
                            <span className={isDark ? 'text-neutral-300' : 'text-neutral-700'}>
                              {item}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Price & Red Action Button (The ONLY clickable element on the card) */}
                    <div className="pt-4 border-t border-dashed border-neutral-700/30 dark:border-neutral-700/50 flex items-center justify-between gap-3">
                      <div>{formatPrice(product.priceTomans, product.priceUsd)}</div>

                      <button
                        type="button"
                        id={`view-product-btn-${product.id}`}
                        onClick={() => setSelectedProduct(product)}
                        className="p-2.5 rounded-xl bg-[#ee2524] text-white hover:bg-[#d41f1e] active:scale-95 transition-all duration-150 cursor-pointer shadow-md shadow-[#ee2524]/20 flex items-center justify-center hover:scale-105"
                        title={lang === 'fa' ? 'مشاهده برگه کارشناسی و مشخصات' : 'View Diagnostic Sheet & Specs'}
                        aria-label={lang === 'fa' ? `مشاهده برگه کارشناسی ${title}` : `View specs for ${title}`}
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {/* DETAIL & DIAGNOSTIC MODAL */}
      {selectedProduct && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setSelectedProduct(null)}
          className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-hidden"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className={`relative w-full max-w-3xl rounded-3xl border shadow-2xl flex flex-col max-h-[90vh] overflow-hidden transition-all duration-200 ${
              isDark
                ? 'bg-neutral-900 border-white/15 text-white shadow-black/80'
                : 'bg-white border-neutral-300 text-[#0D0D0D] shadow-2xl'
            }`}
          >
              {/* Modal Top Header with Prominent "Return" Button */}
              <div
                className={`flex items-center justify-between px-5 py-4 border-b shrink-0 ${
                  isDark ? 'border-neutral-800 bg-neutral-900' : 'border-neutral-200 bg-neutral-50'
                }`}
                dir={lang === 'fa' ? 'rtl' : 'ltr'}
              >
                {/* Back to Products Button */}
                <button
                  type="button"
                  onClick={() => setSelectedProduct(null)}
                  className={`inline-flex items-center gap-2 text-xs sm:text-sm font-semibold px-4 py-2 rounded-full border transition-all duration-150 cursor-pointer ${
                    isDark
                      ? 'bg-neutral-800 hover:bg-neutral-700 border-neutral-700 text-neutral-200 hover:text-white'
                      : 'bg-white hover:bg-neutral-100 border-neutral-300 text-neutral-800 hover:text-black shadow-xs'
                  }`}
                >
                  {lang === 'fa' ? <ArrowRight className="w-4 h-4 text-[#ee2524]" /> : <ArrowLeft className="w-4 h-4 text-[#ee2524]" />}
                  <span>{lang === 'fa' ? 'بازگشت به ویترین محصولات' : 'Return to Showcase'}</span>
                </button>

                {/* Close X Button */}
                <button
                  type="button"
                  onClick={() => setSelectedProduct(null)}
                  aria-label="Close modal"
                  className={`p-2 rounded-full border transition-colors cursor-pointer ${
                    isDark
                      ? 'border-neutral-700 hover:bg-neutral-800 text-neutral-400 hover:text-white'
                      : 'border-neutral-300 hover:bg-neutral-200 text-neutral-600 hover:text-black'
                  }`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Scrollable Body */}
              <div
                className="p-5 sm:p-7 overflow-y-auto space-y-6 flex-1"
                dir={lang === 'fa' ? 'rtl' : 'ltr'}
              >
                {/* Image + Basic Info Row */}
                <div className="flex flex-col sm:flex-row gap-5">
                  <div className="relative w-full sm:w-64 aspect-[4/3] rounded-2xl overflow-hidden bg-neutral-950 shrink-0 border border-white/10">
                    <Image
                      src={selectedProduct.image}
                      alt={selectedProduct.name}
                      fill
                      className="object-cover"
                    />
                    {selectedProduct.badgeFa && (
                      <div className="absolute top-3 right-3 z-10 px-2.5 py-1 rounded-md text-[11px] font-semibold bg-[#ee2524] text-white shadow-md">
                        {lang === 'fa' ? selectedProduct.badgeFa : selectedProduct.badgeEn}
                      </div>
                    )}
                  </div>

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-[#ee2524]/10 text-[#ee2524] mb-2.5">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{lang === 'fa' ? selectedProduct.conditionFa : selectedProduct.conditionEn}</span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-bold mb-2">
                        {lang === 'fa' ? selectedProduct.name : selectedProduct.nameEn}
                      </h3>
                      <div className="text-xs font-mono text-[#999999] mb-4">
                        {lang === 'fa' ? selectedProduct.categoryFa : selectedProduct.categoryEn}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-dashed border-neutral-700/30">
                      <div className="mb-2">
                        {formatPrice(selectedProduct.priceTomans, selectedProduct.priceUsd)}
                      </div>
                      <div className="text-xs font-mono text-[#ee2524] flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{lang === 'fa' ? selectedProduct.warrantyFa : selectedProduct.warrantyEn}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Product Description Narrative */}
                {((lang === 'fa' ? selectedProduct.descriptionFa : selectedProduct.descriptionEn) || selectedProduct.descriptionFa) && (
                  <div
                    className={`p-4 sm:p-5 rounded-2xl border text-xs sm:text-sm leading-relaxed ${
                      isDark ? 'bg-white/[0.03] border-white/10 text-neutral-300' : 'bg-neutral-50 border-neutral-200/80 text-neutral-700'
                    }`}
                  >
                    <div className="font-bold text-xs font-mono text-[#999999] uppercase tracking-wider mb-2">
                      {lang === 'fa' ? 'درباره این کالا و کارشناسی کارخانه:' : 'About This Gear & Karxane Appraisal:'}
                    </div>
                    <p className="leading-relaxed">
                      {lang === 'fa'
                        ? selectedProduct.descriptionFa || selectedProduct.descriptionEn
                        : selectedProduct.descriptionEn || selectedProduct.descriptionFa}
                    </p>
                  </div>
                )}

                {/* Diagnostic Sheet Box */}
                <div
                  className={`p-4 sm:p-5 rounded-2xl border text-xs sm:text-sm leading-relaxed ${
                    isDark ? 'bg-black/50 border-neutral-700 text-neutral-200' : 'bg-neutral-100/90 border-neutral-200 text-neutral-800'
                  }`}
                >
                  <div className="font-bold text-[#ee2524] mb-2 flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    <span>
                      {lang === 'fa'
                        ? 'برگه عیب‌یابی و تاییدیه فنی سیرنگ سرویس (شیراز):'
                        : 'Sirang Service Bench Test Diagnostic Report (Shiraz Lab):'}
                    </span>
                  </div>
                  <p className="leading-relaxed">
                    {lang === 'fa' ? selectedProduct.diagnosticInfoFa || 'کلیه تست‌های دیافراگم، هم‌محوری عدسی‌ها و سلامت شاتر در آزمایشگاه شیراز با موفقیت انجام شده است.' : selectedProduct.diagnosticInfoEn || 'All aperture, optical alignment, and shutter speed tests verified at Shiraz lab.'}
                  </p>
                </div>

                {/* Technical Specs Checklist */}
                <div>
                  <h4 className="font-bold text-xs font-mono text-[#999999] uppercase tracking-wider mb-3">
                    {lang === 'fa' ? 'مشخصات فنی و متعلقات کامل دستگاه:' : 'Technical Specifications & Inclusions:'}
                  </h4>
                  <ul className="space-y-2.5 text-xs sm:text-sm">
                    {((lang === 'fa' ? selectedProduct.specsFa : selectedProduct.specsEn) || []).map((spec, i) => (
                      <li key={i} className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-[#ee2524] shrink-0 mt-0.5" />
                        <span className={isDark ? 'text-neutral-300' : 'text-neutral-700'}>{spec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Modal Bottom Footer Actions */}
              <div
                className={`flex items-center gap-3 p-4 sm:p-5 border-t shrink-0 ${
                  isDark ? 'border-neutral-800 bg-neutral-900' : 'border-neutral-200 bg-neutral-50'
                }`}
                dir={lang === 'fa' ? 'rtl' : 'ltr'}
              >
                <button
                  type="button"
                  onClick={() => {
                    const prod = selectedProduct;
                    setSelectedProduct(null);
                    onSelectProductForInquiry(prod);
                  }}
                  className="flex-1 py-3 px-5 rounded-full bg-[#ee2524] text-white font-semibold text-xs sm:text-sm text-center hover:bg-[#d41f1e] shadow-md shadow-[#ee2524]/20 transition-all cursor-pointer"
                >
                  {t.inquireBtn}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedProduct(null)}
                  className={`py-3 px-6 rounded-full border text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                    isDark
                      ? 'border-neutral-700 hover:bg-neutral-800 text-neutral-300 hover:text-white'
                      : 'border-neutral-300 hover:bg-neutral-200 text-neutral-800'
                  }`}
                >
                  {lang === 'fa' ? 'بازگشت' : 'Back'}
                </button>
              </div>
            </div>
          </div>
        )}
    </section>
  );
}
