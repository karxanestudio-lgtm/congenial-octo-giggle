import * as THREE from 'three';

export interface WireCameraMaterials {
  wireMat: THREE.LineBasicMaterial;
  accentWireMat: THREE.LineBasicMaterial;
  reticleMat: THREE.LineBasicMaterial;
  redWireMat: THREE.LineBasicMaterial;
}

export interface ExplodedCameraParts {
  masterRig: THREE.Group;
  bodyGroup: THREE.Group;
  gripGroup: THREE.Group;
  pentaprismGroup: THREE.Group;
  topDialsGroup: THREE.Group;
  rearChassisGroup: THREE.Group;
  rearLcdGroup: THREE.Group;
  rearControlsGroup: THREE.Group;
  eyecupGroup: THREE.Group;
  // Lens segments for exploded view
  lensMountGroup: THREE.Group;
  lensDistanceGroup: THREE.Group;
  lensZoomGroup: THREE.Group;
  lensSwitchGroup: THREE.Group;
  lensFocusGroup: THREE.Group;
  lensFrontGroup: THREE.Group;
  lensGlassGroup: THREE.Group;
  lensIrisGroup: THREE.Group;
  // CAD measurement & optical reticle guides
  opticsGuideGroup: THREE.Group;
  reticleRings: THREE.Line[];
  // Methods
  setExplosionProgress: (progress: number, isMobile?: boolean) => void;
  updateMaterials: (isDark: boolean) => void;
  dispose: () => void;
}

/**
 * Creates precision filleted box geometry with rounded edges.
 */
function createFilletedBoxGeometry(
  width: number,
  height: number,
  depth: number,
  radius: number,
  smoothness: number = 3
): THREE.BufferGeometry {
  const maxRadius = Math.min(width, height, depth) * 0.48;
  const r = Math.max(0.005, Math.min(radius, maxRadius));
  const hw = width / 2 - r;
  const hh = height / 2 - r;

  const shape = new THREE.Shape();
  shape.moveTo(-hw, -hh - r);
  shape.lineTo(hw, -hh - r);
  shape.absarc(hw, -hh, r, -Math.PI / 2, 0, false);
  shape.lineTo(hw + r, hh);
  shape.absarc(hw, hh, r, 0, Math.PI / 2, false);
  shape.lineTo(-hw, hh + r);
  shape.absarc(-hw, hh, r, Math.PI / 2, Math.PI, false);
  shape.lineTo(-hw - r, -hh);
  shape.absarc(-hw, -hh, r, Math.PI, Math.PI * 1.5, false);

  const extrudeDepth = Math.max(0.001, depth - 2 * r);
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: extrudeDepth,
    bevelEnabled: true,
    bevelSegments: smoothness,
    steps: 1,
    bevelSize: r,
    bevelThickness: r,
  });
  geo.center();
  return geo;
}

/**
 * Generates pure CAD vector line segments from geometry edges.
 */
function createWireframeFromGeometry(
  geometry: THREE.BufferGeometry,
  material: THREE.LineBasicMaterial,
  thresholdAngle: number = 18
): THREE.LineSegments {
  const edges = new THREE.EdgesGeometry(geometry, thresholdAngle);
  return new THREE.LineSegments(edges, material);
}

/**
 * Ultra-lightweight GPU CAD Quad Grid ShaderMaterial with Studio Lighting & Fresnel Depth.
 * Zero CPU overhead, runs 100% on GPU fragment shader with anti-aliased triplanar quad lines.
 * Perfectly covers all surfaces with a fine #999999 linear grid with subtle 3D curvature highlights.
 */
function createCadGridShaderMaterial(isDark: boolean): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: {
      uGridColor: { value: new THREE.Color(0x999999) },
      uBaseColor: { value: new THREE.Color(isDark ? 0x141414 : 0xf2f2f2) },
      uBaseAlpha: { value: isDark ? 0.22 : 0.16 },
      uLineAlpha: { value: 0.95 },
      uGridScale: { value: 24.0 }, // Fine technical engineering quad grid
      uLineWidth: { value: 1.15 },
    },
    vertexShader: `
      varying vec3 vLocalPos;
      varying vec3 vNormalVec;
      varying vec3 vViewDir;
      void main() {
        vLocalPos = position;
        vNormalVec = normalize(normalMatrix * normal);
        vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
        vViewDir = -normalize(mvPos.xyz);
        gl_Position = projectionMatrix * mvPos;
      }
    `,
    fragmentShader: `
      uniform vec3 uGridColor;
      uniform vec3 uBaseColor;
      uniform float uBaseAlpha;
      uniform float uLineAlpha;
      uniform float uGridScale;
      uniform float uLineWidth;
      varying vec3 vLocalPos;
      varying vec3 vNormalVec;
      varying vec3 vViewDir;

      void main() {
        vec3 coord = vLocalPos * uGridScale;
        vec3 dCoord = max(fwidth(coord), vec3(0.0001));
        vec3 g = abs(fract(coord - 0.5) - 0.5) / dCoord;

        vec3 b = abs(vNormalVec);
        b /= max(b.x + b.y + b.z, 0.0001);

        // Smooth anti-aliased edge sampling for crisp lines (+20% sharpness)
        vec3 lineSmooth = 1.0 - smoothstep(vec3(0.0), vec3(uLineWidth), g);

        float px = max(lineSmooth.y, lineSmooth.z);
        float py = max(lineSmooth.x, lineSmooth.z);
        float pz = max(lineSmooth.x, lineSmooth.y);

        float lineIntensity = clamp(px * b.x + py * b.y + pz * b.z, 0.0, 1.0);

        // Subtle studio key lighting (directional light + soft ambient)
        vec3 lightDir = normalize(vec3(0.45, 0.75, 0.6));
        float diff = max(dot(vNormalVec, lightDir), 0.0) * 0.28;

        // Subtle Fresnel rim lighting for curvature definition and 3D depth
        float fresnel = pow(1.0 - max(dot(vNormalVec, vViewDir), 0.0), 2.2) * 0.24;

        vec3 litBase = uBaseColor * (0.86 + diff) + vec3(fresnel * 0.45);
        vec3 litGrid = uGridColor * (0.92 + diff * 0.35) + vec3(fresnel * 0.3);

        vec3 col = mix(litBase, litGrid, lineIntensity);
        float alpha = mix(uBaseAlpha + fresnel * 0.12, uLineAlpha, lineIntensity);

        gl_FragColor = vec4(col, alpha);
      }
    `,
    transparent: true,
    depthTest: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: 1,
    polygonOffsetUnits: 1,
    side: THREE.DoubleSide,
  });
}

/**
 * Creates a component with both fine quad grid surface and precision outline linework.
 */
function createGridPart(
  geometry: THREE.BufferGeometry,
  gridMaterial: THREE.Material,
  wireMaterial: THREE.LineBasicMaterial,
  thresholdAngle: number = 18
): THREE.Group {
  const group = new THREE.Group();
  const mesh = new THREE.Mesh(geometry, gridMaterial);
  const wire = createWireframeFromGeometry(geometry, wireMaterial, thresholdAngle);
  group.add(mesh, wire);
  return group;
}

/**
 * Creates knurled radial ribs and barrel contours with quad grid surface.
 */
function createKnurledRingWithGrid(
  radius: number,
  height: number,
  ribCount: number,
  gridMaterial: THREE.Material,
  materials: WireCameraMaterials
): THREE.Group {
  const group = new THREE.Group();

  const cylGeo = new THREE.CylinderGeometry(radius, radius, height, 48);
  const mesh = new THREE.Mesh(cylGeo, gridMaterial);
  const cylWire = createWireframeFromGeometry(cylGeo, materials.wireMat, 18);
  group.add(mesh, cylWire);

  // Radial knurling precision line segments
  const ribPoints: THREE.Vector3[] = [];
  const ribRadius = radius * 1.01;
  const halfH = height * 0.46;

  for (let i = 0; i < ribCount; i++) {
    const angle = (i / ribCount) * Math.PI * 2;
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    ribPoints.push(
      new THREE.Vector3(cos * ribRadius, -halfH, sin * ribRadius),
      new THREE.Vector3(cos * ribRadius, halfH, sin * ribRadius)
    );
  }

  const ribGeo = new THREE.BufferGeometry().setFromPoints(ribPoints);
  const ribLines = new THREE.LineSegments(ribGeo, materials.accentWireMat);
  group.add(ribLines);

  return group;
}

/**
 * Builds the Precision CAD Line-Art DSLR Camera with Fine Linear Quad Grid Texture.
 * All body, lens, and separated components are covered in #999999 fine linear grid.
 */
export function buildProceduralDslrCamera(isDark: boolean): ExplodedCameraParts {
  const masterRig = new THREE.Group();

  // 1. Color Definition: #999999 as requested
  const mainColor = 0x999999;
  const accentColor = isDark ? 0xb8b8b8 : 0x777777;
  const reticleColor = 0x888888;
  const redColor = 0xee2524;

  const wireMat = new THREE.LineBasicMaterial({
    color: mainColor,
    transparent: true,
    opacity: 0.92,
    depthTest: true,
  });

  const accentWireMat = new THREE.LineBasicMaterial({
    color: accentColor,
    transparent: true,
    opacity: 0.95,
    depthTest: true,
  });

  const reticleMat = new THREE.LineBasicMaterial({
    color: reticleColor,
    transparent: true,
    opacity: 0.55,
    depthTest: true,
  });

  const redWireMat = new THREE.LineBasicMaterial({
    color: redColor,
    transparent: true,
    opacity: 0.95,
    depthTest: true,
  });

  const materials: WireCameraMaterials = {
    wireMat,
    accentWireMat,
    reticleMat,
    redWireMat,
  };

  const cadGridMat = createCadGridShaderMaterial(isDark);

  // 2. Component Groups for Exploded View
  const bodyGroup = new THREE.Group();
  const gripGroup = new THREE.Group();
  const pentaprismGroup = new THREE.Group();
  const topDialsGroup = new THREE.Group();

  const rearChassisGroup = new THREE.Group();
  const rearLcdGroup = new THREE.Group();
  const rearControlsGroup = new THREE.Group();

  const eyecupGroup = new THREE.Group();

  // Lens Groups
  const lensMountGroup = new THREE.Group();
  const lensDistanceGroup = new THREE.Group();
  const lensZoomGroup = new THREE.Group();
  const lensSwitchGroup = new THREE.Group();
  const lensFocusGroup = new THREE.Group();
  const lensFrontGroup = new THREE.Group();
  const lensGlassGroup = new THREE.Group();
  const lensIrisGroup = new THREE.Group();

  // Optical Reticle Guides
  const opticsGuideGroup = new THREE.Group();

  // Camera Assembly container with pivot point centered directly at the lens barrel
  const cameraAssembly = new THREE.Group();
  cameraAssembly.position.set(0, -0.08, -1.8);

  cameraAssembly.add(
    bodyGroup,
    gripGroup,
    pentaprismGroup,
    topDialsGroup,
    rearChassisGroup,
    rearLcdGroup,
    rearControlsGroup,
    eyecupGroup,
    lensMountGroup,
    lensDistanceGroup,
    lensZoomGroup,
    lensSwitchGroup,
    lensFocusGroup,
    lensFrontGroup,
    lensGlassGroup,
    lensIrisGroup,
    opticsGuideGroup
  );

  masterRig.add(cameraAssembly);

  // =========================================================================
  // A. MAIN CAMERA CHASSIS (CORE BODY) WITH FINE LINEAR QUAD GRID
  // =========================================================================
  const chassisGeo = createFilletedBoxGeometry(3.2, 2.1, 1.35, 0.26, 3);
  const chassisPart = createGridPart(chassisGeo, cadGridMat, materials.wireMat, 16);
  chassisPart.position.set(-0.15, 0.05, 0);
  bodyGroup.add(chassisPart);

  // Left curved shoulder
  const leftShoulderGeo = new THREE.CylinderGeometry(0.68, 0.68, 2.02, 36, 1, false, 0, Math.PI);
  const leftShoulderPart = createGridPart(leftShoulderGeo, cadGridMat, materials.wireMat, 15);
  leftShoulderPart.rotation.y = Math.PI * 0.5;
  leftShoulderPart.position.set(-1.75, 0.05, 0);
  bodyGroup.add(leftShoulderPart);

  // Camera Strap Lug Left
  const strapLugLeftGeo = new THREE.TorusGeometry(0.12, 0.035, 12, 24);
  const strapLugLeftWire = createWireframeFromGeometry(strapLugLeftGeo, materials.wireMat, 15);
  strapLugLeftWire.rotation.y = Math.PI * 0.5;
  strapLugLeftWire.position.set(-1.8, 0.65, 0);
  bodyGroup.add(strapLugLeftWire);

  // Camera Strap Lug Right
  const strapLugRightWire = strapLugLeftWire.clone();
  strapLugRightWire.position.set(2.0, 0.65, 0);
  gripGroup.add(strapLugRightWire);

  // Front Lens Mount Flange Ring
  const mountPlateGeo = new THREE.CylinderGeometry(1.02, 1.08, 0.16, 48);
  const mountPlatePart = createGridPart(mountPlateGeo, cadGridMat, materials.accentWireMat, 18);
  mountPlatePart.rotation.x = Math.PI * 0.5;
  mountPlatePart.position.set(0, 0.08, 0.74);
  bodyGroup.add(mountPlatePart);

  // Bayonet locking tabs vector circle
  const bayonetRingGeo = new THREE.TorusGeometry(0.85, 0.05, 12, 48);
  const bayonetRingPart = createGridPart(bayonetRingGeo, cadGridMat, materials.accentWireMat, 15);
  bayonetRingPart.position.set(0, 0.08, 0.83);
  bodyGroup.add(bayonetRingPart);

  // Lens Release Button
  const releaseBtnGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.12, 20);
  const releaseBtnPart = createGridPart(releaseBtnGeo, cadGridMat, materials.wireMat, 15);
  releaseBtnPart.rotation.x = Math.PI * 0.5;
  releaseBtnPart.position.set(-1.08, -0.05, 0.72);
  bodyGroup.add(releaseBtnPart);

  // Red Alignment Dot Circle
  const redDotGeo = new THREE.TorusGeometry(0.04, 0.012, 8, 16);
  const redDotWire = createWireframeFromGeometry(redDotGeo, materials.redWireMat, 15);
  redDotWire.position.set(0, 1.0, 0.8);
  bodyGroup.add(redDotWire);

  // --- Full-Frame 35mm CMOS Image Sensor Assembly (Revealed on Lens Explosion) ---
  // Sensor Cavity Frame Recess
  const sensorCavityGeo = createFilletedBoxGeometry(1.6, 1.25, 0.35, 0.08, 2);
  const sensorCavityPart = createGridPart(sensorCavityGeo, cadGridMat, materials.accentWireMat, 15);
  sensorCavityPart.position.set(0, 0.08, 0.48);
  bodyGroup.add(sensorCavityPart);

  // Full-Frame 36x24mm Sensor Glass Die (3:2 Optical Aspect Ratio)
  const sensorDieGeo = createFilletedBoxGeometry(1.24, 0.84, 0.04, 0.02, 2);
  const sensorDiePart = createGridPart(sensorDieGeo, cadGridMat, materials.accentWireMat, 15);
  sensorDiePart.position.set(0, 0.08, 0.38);
  bodyGroup.add(sensorDiePart);

  // Sensor Bayer Filter Array Reticle & Central AF Target
  const sensorGridPoints: THREE.Vector3[] = [
    new THREE.Vector3(-0.54, 0.08 - 0.34, 0.41),
    new THREE.Vector3(0.54, 0.08 - 0.34, 0.41),
    new THREE.Vector3(0.54, 0.08 + 0.34, 0.41),
    new THREE.Vector3(-0.54, 0.08 + 0.34, 0.41),
    new THREE.Vector3(-0.54, 0.08 - 0.34, 0.41),
    // Center optical alignment crosshairs
    new THREE.Vector3(-0.16, 0.08, 0.41),
    new THREE.Vector3(0.16, 0.08, 0.41),
    new THREE.Vector3(0, 0.08 - 0.12, 0.41),
    new THREE.Vector3(0, 0.08 + 0.12, 0.41),
  ];
  const sensorGridGeo = new THREE.BufferGeometry().setFromPoints(sensorGridPoints);
  const sensorGridLine = new THREE.LineSegments(sensorGridGeo, materials.accentWireMat);
  bodyGroup.add(sensorGridLine);

  // Precision mechanical shutter curtain slats
  for (let s = -2; s <= 2; s++) {
    const shutterBladeGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-0.52, 0.08 + s * 0.13, 0.43),
      new THREE.Vector3(0.52, 0.08 + s * 0.13, 0.43),
    ]);
    const shutterLine = new THREE.Line(shutterBladeGeo, materials.wireMat);
    bodyGroup.add(shutterLine);
  }

  // Base Plate & Tripod Mount
  const tripodSocketGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.08, 24);
  const tripodPart = createGridPart(tripodSocketGeo, cadGridMat, materials.wireMat, 15);
  tripodPart.position.set(0, -1.02, 0);
  bodyGroup.add(tripodPart);

  // Base rubber pad line
  const basePadGeo = createFilletedBoxGeometry(1.4, 0.04, 0.9, 0.015, 2);
  const basePadPart = createGridPart(basePadGeo, cadGridMat, materials.wireMat, 18);
  basePadPart.position.set(-0.8, -1.02, 0);
  bodyGroup.add(basePadPart);

  // =========================================================================
  // B. SCULPTED ERGONOMIC RIGHT HAND GRIP WITH FINE LINEAR QUAD GRID
  // =========================================================================
  const gripMainGeo = createFilletedBoxGeometry(0.85, 2.15, 1.15, 0.22, 3);
  const gripMainPart = createGridPart(gripMainGeo, cadGridMat, materials.wireMat, 18);
  gripMainPart.position.set(1.68, 0.02, 0.35);
  gripGroup.add(gripMainPart);

  // Grip finger curve profile
  const gripCurveGeo = new THREE.CylinderGeometry(0.48, 0.52, 2.05, 36, 1, false, -Math.PI * 0.3, Math.PI * 0.9);
  const gripCurvePart = createGridPart(gripCurveGeo, cadGridMat, materials.wireMat, 15);
  gripCurvePart.position.set(1.72, 0.02, 0.82);
  gripGroup.add(gripCurvePart);

  // Signature Pro Red Accent Inset Line
  const redAccentGeo = createFilletedBoxGeometry(0.04, 0.65, 0.12, 0.018, 2);
  const redAccentWire = createWireframeFromGeometry(redAccentGeo, materials.redWireMat, 15);
  redAccentWire.position.set(1.45, 0.35, 0.95);
  gripGroup.add(redAccentWire);

  // Front Command Dial
  const frontDialGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.12, 24);
  const frontDialPart = createGridPart(frontDialGeo, cadGridMat, materials.accentWireMat, 15);
  frontDialPart.rotation.z = Math.PI * 0.5;
  frontDialPart.position.set(1.78, 0.92, 0.72);
  gripGroup.add(frontDialPart);

  // =========================================================================
  // C. PENTAPRISM & VIEWFINDER HOUSING WITH FINE LINEAR QUAD GRID
  // =========================================================================
  const prismShape = new THREE.Shape();
  prismShape.moveTo(-0.92, 0);
  prismShape.lineTo(-0.78, 0.62);
  prismShape.lineTo(-0.42, 0.88);
  prismShape.lineTo(0.42, 0.88);
  prismShape.lineTo(0.78, 0.62);
  prismShape.lineTo(0.92, 0);
  prismShape.closePath();

  const prismGeo = new THREE.ExtrudeGeometry(prismShape, {
    steps: 1,
    depth: 1.15,
    bevelEnabled: true,
    bevelThickness: 0.14,
    bevelSize: 0.12,
    bevelSegments: 3,
  });
  prismGeo.center();
  const prismPart = createGridPart(prismGeo, cadGridMat, materials.wireMat, 16);
  prismPart.position.set(0, 1.48, 0.08);
  pentaprismGroup.add(prismPart);

  // Pop-up Flash Vector Seam Line
  const flashSeamGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-0.72, 1.45, 0.64),
    new THREE.Vector3(-0.48, 1.78, 0.58),
    new THREE.Vector3(0.48, 1.78, 0.58),
    new THREE.Vector3(0.72, 1.45, 0.64),
  ]);
  const flashSeam = new THREE.Line(flashSeamGeo, materials.accentWireMat);
  pentaprismGroup.add(flashSeam);

  // Stereo Microphone Grilles
  const micGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.04, 12);
  const micL = createWireframeFromGeometry(micGeo, materials.wireMat, 15);
  micL.rotation.x = Math.PI * 0.5;
  micL.position.set(-0.35, 1.75, 0.56);
  const micR = micL.clone();
  micR.position.set(0.35, 1.75, 0.56);
  pentaprismGroup.add(micL, micR);

  // Hot Shoe Flash Mount
  const hotShoeBaseGeo = createFilletedBoxGeometry(0.52, 0.08, 0.56, 0.035, 2);
  const hotShoePart = createGridPart(hotShoeBaseGeo, cadGridMat, materials.accentWireMat, 15);
  hotShoePart.position.set(0, 2.08, 0.08);
  pentaprismGroup.add(hotShoePart);

  // Hot Shoe Rails
  const railGeo = createFilletedBoxGeometry(0.08, 0.06, 0.52, 0.015, 2);
  const railL = createWireframeFromGeometry(railGeo, materials.wireMat, 15);
  railL.position.set(-0.24, 2.12, 0.08);
  const railR = railL.clone();
  railR.position.set(0.24, 2.12, 0.08);
  pentaprismGroup.add(railL, railR);

  // =========================================================================
  // D. TOP CONTROLS & DIALS WITH FINE LINEAR QUAD GRID
  // =========================================================================
  const shutterIslandGeo = createFilletedBoxGeometry(0.68, 0.28, 0.65, 0.08, 2);
  const shutterIslandPart = createGridPart(shutterIslandGeo, cadGridMat, materials.wireMat, 15);
  shutterIslandPart.rotation.x = -0.22;
  shutterIslandPart.position.set(1.65, 1.15, 0.55);
  topDialsGroup.add(shutterIslandPart);

  // Shutter Release Button
  const shutterBtnGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.14, 24);
  const shutterBtnPart = createGridPart(shutterBtnGeo, cadGridMat, materials.accentWireMat, 15);
  shutterBtnPart.rotation.x = -0.22;
  shutterBtnPart.position.set(1.65, 1.34, 0.62);
  topDialsGroup.add(shutterBtnPart);

  // Power Switch Lever
  const powerRingGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.08, 24);
  const powerRingPart = createGridPart(powerRingGeo, cadGridMat, materials.wireMat, 15);
  powerRingPart.rotation.x = -0.22;
  powerRingPart.position.set(1.65, 1.25, 0.6);
  topDialsGroup.add(powerRingPart);

  // Left Shoulder Mode Dial
  const modeDial = createKnurledRingWithGrid(0.42, 0.28, 24, cadGridMat, materials);
  modeDial.position.set(-1.18, 1.22, 0.05);
  topDialsGroup.add(modeDial);

  // Top Status Sub-LCD Frame
  const subLcdFrameGeo = createFilletedBoxGeometry(0.92, 0.08, 0.65, 0.04, 2);
  const subLcdPart = createGridPart(subLcdFrameGeo, cadGridMat, materials.accentWireMat, 15);
  subLcdPart.position.set(1.15, 1.15, -0.05);
  topDialsGroup.add(subLcdPart);

  // Sub-LCD Screen Cross Grid
  const subLcdGridGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(1.15 - 0.35, 1.195, -0.05),
    new THREE.Vector3(1.15 + 0.35, 1.195, -0.05),
    new THREE.Vector3(1.15, 1.195, -0.05 - 0.22),
    new THREE.Vector3(1.15, 1.195, -0.05 + 0.22),
  ]);
  const subLcdGrid = new THREE.LineSegments(subLcdGridGeo, materials.reticleMat);
  topDialsGroup.add(subLcdGrid);

  // Micro Function Buttons
  for (let i = 0; i < 3; i++) {
    const btnGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.06, 12);
    const btnPart = createGridPart(btnGeo, cadGridMat, materials.wireMat, 15);
    btnPart.position.set(0.78 + i * 0.22, 1.2, 0.38);
    topDialsGroup.add(btnPart);
  }

  // =========================================================================
  // E. REAR PANEL (CHASSIS, LCD SCREEN, & CONTROLS - SEPARATE EXPLODED GROUPS)
  // =========================================================================
  // 1. Rear chassis wall & thumb rest
  const rearWallGeo = createFilletedBoxGeometry(3.0, 1.9, 0.12, 0.12, 2);
  const rearWallPart = createGridPart(rearWallGeo, cadGridMat, materials.wireMat, 15);
  rearWallPart.position.set(-0.15, 0.05, -0.68);
  rearChassisGroup.add(rearWallPart);

  const thumbRestGeo = createFilletedBoxGeometry(0.48, 0.65, 0.18, 0.06, 2);
  const thumbRestPart = createGridPart(thumbRestGeo, cadGridMat, materials.wireMat, 15);
  thumbRestPart.position.set(1.58, 0.35, -0.74);
  rearChassisGroup.add(thumbRestPart);

  // 2. Main 3.2" LCD Screen & Display Matrix (Exploded separately)
  const lcdBezelGeo = createFilletedBoxGeometry(2.1, 1.48, 0.08, 0.06, 3);
  const lcdBezelPart = createGridPart(lcdBezelGeo, cadGridMat, materials.accentWireMat, 15);
  lcdBezelPart.position.set(-0.42, -0.05, -0.72);
  rearLcdGroup.add(lcdBezelPart);

  // Technical Grid on LCD Screen (Rule of thirds + Center crosshair)
  const screenGridPoints: THREE.Vector3[] = [
    new THREE.Vector3(-0.42 - 0.95, -0.05 - 0.65, -0.76),
    new THREE.Vector3(-0.42 + 0.95, -0.05 - 0.65, -0.76),
    new THREE.Vector3(-0.42 + 0.95, -0.05 + 0.65, -0.76),
    new THREE.Vector3(-0.42 - 0.95, -0.05 + 0.65, -0.76),
    new THREE.Vector3(-0.42 - 0.95, -0.05 - 0.65, -0.76),
    // Rule of thirds lines
    new THREE.Vector3(-0.42 - 0.32, -0.05 - 0.65, -0.76),
    new THREE.Vector3(-0.42 - 0.32, -0.05 + 0.65, -0.76),
    new THREE.Vector3(-0.42 + 0.32, -0.05 - 0.65, -0.76),
    new THREE.Vector3(-0.42 + 0.32, -0.05 + 0.65, -0.76),
    new THREE.Vector3(-0.42 - 0.95, -0.05 - 0.22, -0.76),
    new THREE.Vector3(-0.42 + 0.95, -0.05 - 0.22, -0.76),
    new THREE.Vector3(-0.42 - 0.95, -0.05 + 0.22, -0.76),
    new THREE.Vector3(-0.42 + 0.95, -0.05 + 0.22, -0.76),
  ];
  const screenGridGeo = new THREE.BufferGeometry().setFromPoints(screenGridPoints);
  const screenGrid = new THREE.Line(screenGridGeo, materials.reticleMat);
  rearLcdGroup.add(screenGrid);

  // AF Focal Points on Screen
  for (let row = -1; row <= 1; row++) {
    for (let col = -1; col <= 1; col++) {
      const afBoxGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(-0.42 + col * 0.4 - 0.04, -0.05 + row * 0.28 - 0.04, -0.762),
        new THREE.Vector3(-0.42 + col * 0.4 + 0.04, -0.05 + row * 0.28 - 0.04, -0.762),
        new THREE.Vector3(-0.42 + col * 0.4 + 0.04, -0.05 + row * 0.28 + 0.04, -0.762),
        new THREE.Vector3(-0.42 + col * 0.4 - 0.04, -0.05 + row * 0.28 + 0.04, -0.762),
        new THREE.Vector3(-0.42 + col * 0.4 - 0.04, -0.05 + row * 0.28 - 0.04, -0.762),
      ]);
      const afBox = new THREE.Line(afBoxGeo, (row === 0 && col === 0) ? materials.redWireMat : materials.accentWireMat);
      rearLcdGroup.add(afBox);
    }
  }

  // 3. Rear Buttons & Rotary D-Pad Controller (Exploded separately)
  const dpadOuter = createKnurledRingWithGrid(0.38, 0.08, 20, cadGridMat, materials);
  dpadOuter.rotation.x = Math.PI * 0.5;
  dpadOuter.position.set(1.22, -0.32, -0.72);
  rearControlsGroup.add(dpadOuter);

  // Center "SET" button inside D-pad
  const dpadCenterGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.1, 20);
  const dpadCenterPart = createGridPart(dpadCenterGeo, cadGridMat, materials.accentWireMat, 15);
  dpadCenterPart.rotation.x = Math.PI * 0.5;
  dpadCenterPart.position.set(1.22, -0.32, -0.75);
  rearControlsGroup.add(dpadCenterPart);

  // Rear Command Buttons
  const rearBtnPositions = [
    [-1.62, 0.45],
    [-1.62, 0.18],
    [-1.62, -0.1],
    [-1.62, -0.38],
    [-1.62, -0.65],
    [1.15, 0.62],
    [1.48, 0.58],
  ];
  rearBtnPositions.forEach(([bx, by]) => {
    const btnGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.08, 16);
    const btnPart = createGridPart(btnGeo, cadGridMat, materials.accentWireMat, 15);
    btnPart.rotation.x = Math.PI * 0.5;
    btnPart.position.set(bx, by, -0.72);
    rearControlsGroup.add(btnPart);
  });

  // =========================================================================
  // F. VIEWFINDER EYECUP & EYEPIECE
  // =========================================================================
  const eyecupOuterGeo = createFilletedBoxGeometry(0.72, 0.58, 0.28, 0.09, 3);
  const eyecupPart = createGridPart(eyecupOuterGeo, cadGridMat, materials.accentWireMat, 15);
  eyecupPart.position.set(0, 1.48, -0.68);
  eyecupGroup.add(eyecupPart);

  // Viewfinder crosshair optics line
  const vfCrossGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-0.24, 1.48, -0.82),
    new THREE.Vector3(0.24, 1.48, -0.82),
    new THREE.Vector3(0, 1.48 - 0.18, -0.82),
    new THREE.Vector3(0, 1.48 + 0.18, -0.82),
  ]);
  const vfCross = new THREE.LineSegments(vfCrossGeo, materials.reticleMat);
  eyecupGroup.add(vfCross);

  // Diopter Adjustment Wheel
  const diopterWheel = createKnurledRingWithGrid(0.12, 0.06, 16, cadGridMat, materials);
  diopterWheel.rotation.z = Math.PI * 0.5;
  diopterWheel.position.set(0.42, 1.48, -0.68);
  eyecupGroup.add(diopterWheel);

  // =========================================================================
  // G. MULTI-SEGMENT PRO ZOOM LENS (PROJECTING ALONG +Z) WITH QUAD GRID
  // =========================================================================
  // 1. Lens Mount Collar & Base Segment
  const mountCollarGeo = new THREE.CylinderGeometry(0.98, 1.02, 0.48, 48);
  const mountCollarPart = createGridPart(mountCollarGeo, cadGridMat, materials.accentWireMat, 18);
  mountCollarPart.rotation.x = Math.PI * 0.5;
  mountCollarPart.position.set(0, 0.08, 1.08);
  lensMountGroup.add(mountCollarPart);

  // Lens Mount Index Red Mark
  const lensRedDotGeo = createFilletedBoxGeometry(0.06, 0.06, 0.08, 0.015, 2);
  const lensRedDotWire = createWireframeFromGeometry(lensRedDotGeo, materials.redWireMat, 15);
  lensRedDotWire.position.set(0, 1.08, 1.08);
  lensMountGroup.add(lensRedDotWire);

  // 2. Distance Scale Window Segment
  const distBarrelGeo = new THREE.CylinderGeometry(1.02, 1.02, 0.42, 48);
  const distBarrelPart = createGridPart(distBarrelGeo, cadGridMat, materials.wireMat, 18);
  distBarrelPart.rotation.x = Math.PI * 0.5;
  distBarrelPart.position.set(0, 0.08, 1.54);
  lensDistanceGroup.add(distBarrelPart);

  // Distance Scale Window Outline
  const scaleWindowGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-0.34, 1.1, 1.54 - 0.11),
    new THREE.Vector3(0.34, 1.1, 1.54 - 0.11),
    new THREE.Vector3(0.34, 1.1, 1.54 + 0.11),
    new THREE.Vector3(-0.34, 1.1, 1.54 + 0.11),
    new THREE.Vector3(-0.34, 1.1, 1.54 - 0.11),
  ]);
  const scaleWindowWire = new THREE.Line(scaleWindowGeo, materials.accentWireMat);
  lensDistanceGroup.add(scaleWindowWire);

  // Scale Tick Lines inside window
  const tickPoints: THREE.Vector3[] = [];
  for (let i = -4; i <= 4; i++) {
    const tx = i * 0.065;
    const th = (i % 2 === 0) ? 0.06 : 0.035;
    tickPoints.push(
      new THREE.Vector3(tx, 1.09, 1.54 - th),
      new THREE.Vector3(tx, 1.09, 1.54 + th)
    );
  }
  const tickGeo = new THREE.BufferGeometry().setFromPoints(tickPoints);
  const tickLines = new THREE.LineSegments(tickGeo, materials.accentWireMat);
  lensDistanceGroup.add(tickLines);

  // 3. Wide Zoom Ring Segment (24-70mm)
  const zoomRing = createKnurledRingWithGrid(1.05, 0.65, 48, cadGridMat, materials);
  zoomRing.rotation.x = Math.PI * 0.5;
  zoomRing.position.set(0, 0.08, 2.12);
  lensZoomGroup.add(zoomRing);

  // Focal Length Number Indicator Rim
  const zoomMarkerRingGeo = new THREE.TorusGeometry(1.06, 0.03, 12, 48);
  const zoomMarkerRingWire = createWireframeFromGeometry(zoomMarkerRingGeo, materials.accentWireMat, 15);
  zoomMarkerRingWire.position.set(0, 0.08, 2.46);
  lensZoomGroup.add(zoomMarkerRingWire);

  // 4. Intermediate Barrel & Switch Plate
  const midBarrelGeo = new THREE.CylinderGeometry(1.06, 1.06, 0.38, 48);
  const midBarrelPart = createGridPart(midBarrelGeo, cadGridMat, materials.wireMat, 18);
  midBarrelPart.rotation.x = Math.PI * 0.5;
  midBarrelPart.position.set(0, 0.08, 2.65);
  lensSwitchGroup.add(midBarrelPart);

  // Switch Plate
  const switchPlateGeo = createFilletedBoxGeometry(0.12, 0.48, 0.28, 0.04, 2);
  const switchPlatePart = createGridPart(switchPlateGeo, cadGridMat, materials.wireMat, 15);
  switchPlatePart.position.set(-1.08, 0.08, 2.65);
  lensSwitchGroup.add(switchPlatePart);

  // Switch sliders
  const slider1Geo = createFilletedBoxGeometry(0.08, 0.12, 0.08, 0.02, 2);
  const slider1Wire = createWireframeFromGeometry(slider1Geo, materials.accentWireMat, 15);
  slider1Wire.position.set(-1.14, 0.18, 2.65);
  const slider2Wire = slider1Wire.clone();
  slider2Wire.position.set(-1.14, -0.05, 2.65);
  lensSwitchGroup.add(slider1Wire, slider2Wire);

  // 5. Precision Focus Ring
  const focusRing = createKnurledRingWithGrid(1.08, 0.55, 56, cadGridMat, materials);
  focusRing.rotation.x = Math.PI * 0.5;
  focusRing.position.set(0, 0.08, 3.14);
  lensFocusGroup.add(focusRing);

  // Signature Pro Luxury Red Ring
  const luxuryRedRingGeo = new THREE.TorusGeometry(1.09, 0.025, 12, 56);
  const luxuryRedRingWire = createWireframeFromGeometry(luxuryRedRingGeo, materials.redWireMat, 15);
  luxuryRedRingWire.position.set(0, 0.08, 3.43);
  lensFocusGroup.add(luxuryRedRingWire);

  // 6. Front Filter Thread & Bevel Barrel
  const frontBarrelGeo = new THREE.CylinderGeometry(1.15, 1.09, 0.38, 48);
  const frontBarrelPart = createGridPart(frontBarrelGeo, cadGridMat, materials.accentWireMat, 18);
  frontBarrelPart.rotation.x = Math.PI * 0.5;
  frontBarrelPart.position.set(0, 0.08, 3.62);
  lensFrontGroup.add(frontBarrelPart);

  // 82mm Filter Thread Grooves
  for (let i = 0; i < 3; i++) {
    const threadRingGeo = new THREE.TorusGeometry(1.14, 0.012, 8, 48);
    const threadRingWire = createWireframeFromGeometry(threadRingGeo, materials.accentWireMat, 15);
    threadRingWire.position.set(0, 0.08, 3.72 + i * 0.03);
    lensFrontGroup.add(threadRingWire);
  }

  // 7. Internal Optical Aperture Stop Chamber (Clean, Precision Engineering - No fan blades)
  const irisHousingGeo = new THREE.CylinderGeometry(0.88, 0.94, 0.28, 48);
  const irisHousingPart = createGridPart(irisHousingGeo, cadGridMat, materials.accentWireMat, 18);
  irisHousingPart.rotation.x = Math.PI * 0.5;
  irisHousingPart.position.set(0, 0.08, 2.3);
  lensIrisGroup.add(irisHousingPart);

  // Aperture Stop Concentric Optical Rings (f/1.4 - f/22 aperture stop calibration)
  const fStopCircles = [0.38, 0.56, 0.72];
  for (const radius of fStopCircles) {
    const fRingGeo = new THREE.TorusGeometry(radius, 0.012, 8, 48);
    const fRingWire = createWireframeFromGeometry(fRingGeo, materials.accentWireMat, 15);
    fRingWire.position.set(0, 0.08, 2.3);
    lensIrisGroup.add(fRingWire);
  }

  // 8. Front Curved Convex Glass Element (Optical Lens Curves & Anti-Reflective Coating)
  const lensRingsCount = 6;
  for (let i = 1; i <= lensRingsCount; i++) {
    const frac = i / lensRingsCount;
    const r = Math.sin(frac * Math.PI * 0.45) * 1.06;
    const zOffset = (1 - Math.cos(frac * Math.PI * 0.45)) * 0.32;
    const glassRingGeo = new THREE.BufferGeometry();
    const gPoints: THREE.Vector3[] = [];
    const segs = 48;
    for (let s = 0; s <= segs; s++) {
      const th = (s / segs) * Math.PI * 2;
      gPoints.push(new THREE.Vector3(Math.cos(th) * r, Math.sin(th) * r, zOffset));
    }
    glassRingGeo.setFromPoints(gPoints);
    const gLine = new THREE.Line(glassRingGeo, materials.accentWireMat);
    gLine.position.set(0, 0.08, 3.48);
    lensGlassGroup.add(gLine);
  }

  // =========================================================================
  // H. OPTICAL CAD RETICLE RINGS & MEASUREMENT CROSSHAIRS
  // =========================================================================
  const reticleRings: THREE.Line[] = [];

  const createOpticalReticle = (radius: number, zPos: number, segments = 48) => {
    const ringGeo = new THREE.BufferGeometry();
    const points: THREE.Vector3[] = [];
    for (let i = 0; i <= segments; i++) {
      const theta = (i / segments) * Math.PI * 2;
      points.push(new THREE.Vector3(Math.cos(theta) * radius, Math.sin(theta) * radius, 0));
    }
    ringGeo.setFromPoints(points);
    const line = new THREE.Line(ringGeo, materials.reticleMat);
    line.position.set(0, 0.08, zPos);
    opticsGuideGroup.add(line);
    reticleRings.push(line);
    return line;
  };

  const ring1 = createOpticalReticle(1.22, 1.2);
  const ring2 = createOpticalReticle(1.35, 2.1);
  const ring3 = createOpticalReticle(1.48, 3.1);
  const ring4 = createOpticalReticle(1.65, 3.8);

  // =========================================================================
  // I. EXPLODED VIEW TRANSFORMATION LOGIC (Multi-Directional 3D Disassembly)
  // =========================================================================
  const initialPositions = {
    bodyGroupX: bodyGroup.position.x,
    bodyGroupY: bodyGroup.position.y,
    bodyGroupZ: bodyGroup.position.z,
    gripGroupX: gripGroup.position.x,
    gripGroupY: gripGroup.position.y,
    gripGroupZ: gripGroup.position.z,
    pentaprismGroupX: pentaprismGroup.position.x,
    pentaprismGroupY: pentaprismGroup.position.y,
    pentaprismGroupZ: pentaprismGroup.position.z,
    topDialsGroupX: topDialsGroup.position.x,
    topDialsGroupY: topDialsGroup.position.y,
    topDialsGroupZ: topDialsGroup.position.z,
    rearChassisX: rearChassisGroup.position.x,
    rearChassisY: rearChassisGroup.position.y,
    rearChassisZ: rearChassisGroup.position.z,
    rearLcdX: rearLcdGroup.position.x,
    rearLcdY: rearLcdGroup.position.y,
    rearLcdZ: rearLcdGroup.position.z,
    rearControlsX: rearControlsGroup.position.x,
    rearControlsY: rearControlsGroup.position.y,
    rearControlsZ: rearControlsGroup.position.z,
    eyecupGroupX: eyecupGroup.position.x,
    eyecupGroupY: eyecupGroup.position.y,
    eyecupGroupZ: eyecupGroup.position.z,
    lensMountX: lensMountGroup.position.x,
    lensMountY: lensMountGroup.position.y,
    lensMountZ: lensMountGroup.position.z,
    lensDistanceX: lensDistanceGroup.position.x,
    lensDistanceY: lensDistanceGroup.position.y,
    lensDistanceZ: lensDistanceGroup.position.z,
    lensZoomX: lensZoomGroup.position.x,
    lensZoomY: lensZoomGroup.position.y,
    lensZoomZ: lensZoomGroup.position.z,
    lensSwitchX: lensSwitchGroup.position.x,
    lensSwitchY: lensSwitchGroup.position.y,
    lensSwitchZ: lensSwitchGroup.position.z,
    lensFocusX: lensFocusGroup.position.x,
    lensFocusY: lensFocusGroup.position.y,
    lensFocusZ: lensFocusGroup.position.z,
    lensFrontX: lensFrontGroup.position.x,
    lensFrontY: lensFrontGroup.position.y,
    lensFrontZ: lensFrontGroup.position.z,
    lensGlassX: lensGlassGroup.position.x,
    lensGlassY: lensGlassGroup.position.y,
    lensGlassZ: lensGlassGroup.position.z,
    lensIrisX: lensIrisGroup.position.x,
    lensIrisY: lensIrisGroup.position.y,
    lensIrisZ: lensIrisGroup.position.z,
  };

  const setExplosionProgress = (progress: number, isMobile: boolean = false) => {
    // Smooth progress clamped to [0, 1] across page scroll
    const p = Math.max(0, Math.min(1, progress));
    const scaleMult = isMobile ? 0.75 : 1.0;

    // Ensure model is visible and bright throughout the entire scroll journey
    wireMat.opacity = 0.92;
    accentWireMat.opacity = 0.95;
    redWireMat.opacity = 0.95;
    reticleMat.opacity = 0.55;
    cadGridMat.uniforms.uBaseAlpha.value = isDark ? 0.22 : 0.16;
    cadGridMat.uniforms.uLineAlpha.value = 0.95;
    masterRig.visible = true;

    // -----------------------------------------------------------------------
    // 1. OPTICAL LENS STACK (Forward +Z with Helical Spins & Radial Offsets)
    // -----------------------------------------------------------------------
    // Lens Mount & Bayonet Flange Ring
    lensMountGroup.position.x = initialPositions.lensMountX;
    lensMountGroup.position.y = initialPositions.lensMountY - p * 0.18 * scaleMult;
    lensMountGroup.position.z = initialPositions.lensMountZ + p * 0.75 * scaleMult;
    lensMountGroup.rotation.z = p * 0.25;

    // Distance Scale Window Ring (Unscrewing motion)
    lensDistanceGroup.position.x = initialPositions.lensDistanceX - p * 0.18 * scaleMult;
    lensDistanceGroup.position.y = initialPositions.lensDistanceY + p * 0.16 * scaleMult;
    lensDistanceGroup.position.z = initialPositions.lensDistanceZ + p * 1.5 * scaleMult;
    lensDistanceGroup.rotation.z = -p * 0.5;

    // Zoom Barrel Group
    lensZoomGroup.position.x = initialPositions.lensZoomX + p * 0.22 * scaleMult;
    lensZoomGroup.position.y = initialPositions.lensZoomY - p * 0.12 * scaleMult;
    lensZoomGroup.position.z = initialPositions.lensZoomZ + p * 2.3 * scaleMult;
    lensZoomGroup.rotation.z = p * 0.7;

    // Mechanical Aperture Iris & Blades (Dynamic aperture rotation)
    lensIrisGroup.position.x = initialPositions.lensIrisX - p * 0.26 * scaleMult;
    lensIrisGroup.position.y = initialPositions.lensIrisY + p * 0.22 * scaleMult;
    lensIrisGroup.position.z = initialPositions.lensIrisZ + p * 3.1 * scaleMult;
    lensIrisGroup.rotation.z = -p * 1.4;

    // AF/MF Switch & Stabilizer Electronics Collar
    lensSwitchGroup.position.x = initialPositions.lensSwitchX + p * 0.42 * scaleMult;
    lensSwitchGroup.position.y = initialPositions.lensSwitchY + p * 0.3 * scaleMult;
    lensSwitchGroup.position.z = initialPositions.lensSwitchZ + p * 4.0 * scaleMult;
    lensSwitchGroup.rotation.x = p * 0.15;
    lensSwitchGroup.rotation.y = p * 0.2;

    // Manual Focus Knurled Ring (Focus helical gear spinning)
    lensFocusGroup.position.x = initialPositions.lensFocusX - p * 0.3 * scaleMult;
    lensFocusGroup.position.y = initialPositions.lensFocusY - p * 0.18 * scaleMult;
    lensFocusGroup.position.z = initialPositions.lensFocusZ + p * 5.0 * scaleMult;
    lensFocusGroup.rotation.z = p * 0.9;

    // Front Filter Thread & Red Luxury Ring
    lensFrontGroup.position.x = initialPositions.lensFrontX + p * 0.28 * scaleMult;
    lensFrontGroup.position.y = initialPositions.lensFrontY + p * 0.26 * scaleMult;
    lensFrontGroup.position.z = initialPositions.lensFrontZ + p * 6.1 * scaleMult;
    lensFrontGroup.rotation.x = -p * 0.12;
    lensFrontGroup.rotation.z = -p * 0.35;

    // Front Aspherical Convex Glass Element (Floating optical crown)
    lensGlassGroup.position.x = initialPositions.lensGlassX - p * 0.15 * scaleMult;
    lensGlassGroup.position.y = initialPositions.lensGlassY + p * 0.36 * scaleMult;
    lensGlassGroup.position.z = initialPositions.lensGlassZ + p * 7.2 * scaleMult;
    lensGlassGroup.rotation.x = p * 0.2;
    lensGlassGroup.rotation.y = -p * 0.2;

    // Optical Guide Laser Rings (Expanded in 3D space)
    ring1.position.z = 1.2 + p * 1.0 * scaleMult;
    ring2.position.z = 2.1 + p * 2.3 * scaleMult;
    ring3.position.z = 3.1 + p * 3.9 * scaleMult;
    ring4.position.z = 3.8 + p * 5.7 * scaleMult;
    ring1.scale.setScalar(1 + p * 0.22);
    ring2.scale.setScalar(1 + p * 0.32);
    ring3.scale.setScalar(1 + p * 0.42);
    ring4.scale.setScalar(1 + p * 0.52);

    // -----------------------------------------------------------------------
    // 2. TOP DECK ASSEMBLY (Separates UPWARDS +Y, Forward +Z and Tilted)
    // -----------------------------------------------------------------------
    // Pentaprism & Optical Viewfinder Hump (Ascends up & tilts forward)
    pentaprismGroup.position.x = initialPositions.pentaprismGroupX;
    pentaprismGroup.position.y = initialPositions.pentaprismGroupY + p * 1.6 * scaleMult;
    pentaprismGroup.position.z = initialPositions.pentaprismGroupZ + p * 0.45 * scaleMult;
    pentaprismGroup.rotation.x = -p * 0.25;

    // Top Command Dials, Shutter Button & Power Switch (Flies UP & RIGHT)
    topDialsGroup.position.x = initialPositions.topDialsGroupX + p * 1.1 * scaleMult;
    topDialsGroup.position.y = initialPositions.topDialsGroupY + p * 2.0 * scaleMult;
    topDialsGroup.position.z = initialPositions.topDialsGroupZ + p * 0.38 * scaleMult;
    topDialsGroup.rotation.z = -p * 0.35;
    topDialsGroup.rotation.x = -p * 0.2;

    // -----------------------------------------------------------------------
    // 3. GRIP ASSEMBLY (Separates RIGHT +X, Forward +Z and Flares Outward)
    // -----------------------------------------------------------------------
    // Sculpted Ergonomic Right Handgrip & Front Dial
    gripGroup.position.x = initialPositions.gripGroupX + p * 1.4 * scaleMult;
    gripGroup.position.y = initialPositions.gripGroupY - p * 0.32 * scaleMult;
    gripGroup.position.z = initialPositions.gripGroupZ + p * 0.55 * scaleMult;
    gripGroup.rotation.y = -p * 0.38;
    gripGroup.rotation.z = p * 0.22;

    // -----------------------------------------------------------------------
    // 4. REAR CHASSIS & ELECTRONICS (Separates BACKWARDS -Z, Left -X and Flips)
    // -----------------------------------------------------------------------
    // Rear Main Magnesium Chassis Plate
    rearChassisGroup.position.x = initialPositions.rearChassisX - p * 0.25 * scaleMult;
    rearChassisGroup.position.y = initialPositions.rearChassisY - p * 0.45 * scaleMult;
    rearChassisGroup.position.z = initialPositions.rearChassisZ - p * 1.4 * scaleMult;
    rearChassisGroup.rotation.x = p * 0.15;

    // Rear Articulating High-Res LCD Screen (Swings open to the LEFT with angle)
    rearLcdGroup.position.x = initialPositions.rearLcdX - p * 1.3 * scaleMult;
    rearLcdGroup.position.y = initialPositions.rearLcdY + p * 0.35 * scaleMult;
    rearLcdGroup.position.z = initialPositions.rearLcdZ - p * 2.5 * scaleMult;
    rearLcdGroup.rotation.y = p * 0.75;
    rearLcdGroup.rotation.x = -p * 0.18;

    // Rear D-Pad, Joystick & Sub-Dial Control Panel (Floats back & to the right)
    rearControlsGroup.position.x = initialPositions.rearControlsX + p * 0.8 * scaleMult;
    rearControlsGroup.position.y = initialPositions.rearControlsY - p * 0.35 * scaleMult;
    rearControlsGroup.position.z = initialPositions.rearControlsZ - p * 3.1 * scaleMult;
    rearControlsGroup.rotation.y = -p * 0.32;
    rearControlsGroup.rotation.z = -p * 0.16;

    // Eyepiece / Optical Viewfinder Eyecup (Pulls back and upward)
    eyecupGroup.position.x = initialPositions.eyecupGroupX - p * 0.18 * scaleMult;
    eyecupGroup.position.y = initialPositions.eyecupGroupY + p * 1.0 * scaleMult;
    eyecupGroup.position.z = initialPositions.eyecupGroupZ - p * 2.1 * scaleMult;
    eyecupGroup.rotation.x = p * 0.3;

    // -----------------------------------------------------------------------
    // 5. CAMERA MAIN BODY CORE
    // -----------------------------------------------------------------------
    bodyGroup.position.x = initialPositions.bodyGroupX;
    bodyGroup.position.y = initialPositions.bodyGroupY;
    bodyGroup.position.z = initialPositions.bodyGroupZ;
  };

  // =========================================================================
  // J. DYNAMIC THEME UPDATE (#999999 Core Scheme)
  // =========================================================================
  const updateMaterials = (dark: boolean) => {
    wireMat.color.setHex(0x999999);
    accentWireMat.color.setHex(dark ? 0xb8b8b8 : 0x777777);
    cadGridMat.uniforms.uGridColor.value.setHex(0x999999);
    cadGridMat.uniforms.uBaseColor.value.setHex(dark ? 0x141414 : 0xf2f2f2);
    cadGridMat.uniforms.uBaseAlpha.value = dark ? 0.22 : 0.16;
  };

  // =========================================================================
  // K. CLEAN DISPOSAL
  // =========================================================================
  const dispose = () => {
    masterRig.traverse((object) => {
      if ((object as THREE.Mesh).isMesh) {
        const mesh = object as THREE.Mesh;
        mesh.geometry?.dispose();
      }
      if ((object as THREE.Line).isLine || (object as THREE.LineSegments).isLineSegments) {
        const line = object as THREE.Line;
        line.geometry?.dispose();
      }
    });

    cadGridMat.dispose();
    wireMat.dispose();
    accentWireMat.dispose();
    reticleMat.dispose();
    redWireMat.dispose();
  };

  return {
    masterRig,
    bodyGroup,
    gripGroup,
    pentaprismGroup,
    topDialsGroup,
    rearChassisGroup,
    rearLcdGroup,
    rearControlsGroup,
    eyecupGroup,
    lensMountGroup,
    lensDistanceGroup,
    lensZoomGroup,
    lensSwitchGroup,
    lensFocusGroup,
    lensFrontGroup,
    lensGlassGroup,
    lensIrisGroup,
    opticsGuideGroup,
    reticleRings,
    setExplosionProgress,
    updateMaterials,
    dispose,
  };
}
