'use client';

import React, { useState } from 'react';
import { TEAM_MEMBERS, TRANSLATIONS } from '@/lib/translations';
import { Language } from '@/types';
import { Quote, BookOpen, User, X } from 'lucide-react';
import { KarxaneMark } from './KarxaneLogos';

interface AboutSectionProps {
  lang: Language;
  isDark: boolean;
}

export function AboutSection({ lang, isDark }: AboutSectionProps) {
  const [showFullStoryModal, setShowFullStoryModal] = useState<boolean>(false);

  const t = TRANSLATIONS[lang];

  return (
    <section
      id="about"
      className="py-24 relative z-10 bg-transparent transition-colors duration-300 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* BRAND STORY CONTAINER */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center mb-20">
          {/* Visual Emblem Column */}
          <div
            className={`lg:col-span-5 flex flex-col items-center justify-center text-center p-8 sm:p-12 rounded-3xl border relative overflow-hidden md:backdrop-blur-xs shadow-xl transition-all duration-300 ${
              isDark
                ? 'bg-gradient-to-b from-neutral-800/90 via-neutral-900/80 to-neutral-950/95 border-white/15 text-white shadow-black/50'
                : 'bg-gradient-to-b from-white via-neutral-100/90 to-neutral-200/80 border-neutral-300/80 text-[#0D0D0D] shadow-xl shadow-neutral-300/40'
            }`}
          >
            <div className={`mb-6 p-6 rounded-2xl border md:backdrop-blur-xs ${
              isDark ? 'bg-black/40 border-white/10' : 'bg-white border-neutral-300/70 shadow-sm'
            }`}>
              <KarxaneMark className="w-20 h-28 text-current" />
            </div>

            <div className="font-mono text-xs tracking-widest text-[#ee2524] uppercase mb-1">
              {lang === 'fa' ? 'شیراز ۱۴۰۵' : 'EST. SHIRAZ 2026'}
            </div>
            <h3 className="text-2xl font-bold tracking-tight mb-3">
              {lang === 'fa' ? 'استودیو کارخانه' : 'Studio Kārxāne'}
            </h3>
            <p className={`text-xs max-w-xs leading-relaxed ${isDark ? 'text-neutral-300' : 'text-neutral-600'}`}>
              {lang === 'fa'
                ? 'مرکز تخصصی تعمیر، تاریکخانه، تجهیزات و کتابخانه تصویر'
                : 'Specialized optical repair lab, darkroom, equipment hub & visual arts bookstore'}
            </p>

            {/* Philosophy quote */}
            <div className="mt-8 pt-6 border-t border-dashed border-neutral-700/40 dark:border-neutral-700/60 w-full text-center">
              <Quote className="w-5 h-5 text-[#ee2524] mx-auto mb-2 opacity-70" />
              <p className="text-xs sm:text-sm font-medium italic text-[#ee2524]">
                {lang === 'fa'
                  ? '«کتاب هم مثل دوربین، ابزار کار است، برای بهتر دیدن و بهتر ثبت کردن!»'
                  : '"A book, just like a camera, is an essential tool — for seeing better, and capturing deeper!"'}
              </p>
            </div>
          </div>

          {/* Story Text Column */}
          <div
            className={`lg:col-span-7 flex flex-col justify-center p-8 sm:p-10 rounded-3xl border md:backdrop-blur-xs transition-all duration-300 shadow-xl ${
              isDark
                ? 'bg-gradient-to-b from-neutral-800/90 via-neutral-900/80 to-neutral-950/95 border-white/15 text-white shadow-black/50'
                : 'bg-gradient-to-b from-white via-neutral-100/90 to-neutral-200/80 border-neutral-300/80 text-[#0D0D0D] shadow-xl shadow-neutral-300/40'
            }`}
          >
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight mb-6 leading-tight">
              {t.aboutBrandTitle}
            </h2>

            {/* Authentic story paragraph requested by user */}
            <div className="space-y-4 text-base sm:text-lg leading-relaxed mb-8">
              <p className={isDark ? 'text-neutral-200' : 'text-neutral-800'}>
                {t.aboutStoryParagraph}
              </p>
              <p className={`text-sm sm:text-base ${isDark ? 'text-neutral-300' : 'text-neutral-600'}`}>
                {t.aboutStorySecondary}
              </p>
            </div>

            {/* Four Spaces bullet summary with Gray-to-Transparent Glassmorphism */}
            <div className="grid grid-cols-2 gap-3 mb-8 text-xs sm:text-sm">
              {[
                {
                  titleFa: '۱. تعمیرخانه',
                  titleEn: '1. Repair Lab',
                  descFa: 'نمایندگی رسمی سیرنگ با ۳ ماه ضمانت کتبی',
                  descEn: 'Official Sirang Agent with 3-month warranty',
                },
                {
                  titleFa: '۲. تاریکخانه',
                  titleEn: '2. Darkroom Lab',
                  descFa: 'ظهور و اسکن نگاتیو و فیلم تازه',
                  descEn: 'Film dev, 48-bit scan & vintage sales',
                },
                {
                  titleFa: '۳. کارخانه',
                  titleEn: '3. Equipment Hub',
                  descFa: 'تجهیزات نو و کارکرده با برگه عیب‌یابی',
                  descEn: 'New & certified pre-owned with check sheet',
                },
                {
                  titleFa: '۴. کتابخانه',
                  titleEn: '4. Artbook Library',
                  descFa: 'کتابفروشی تخصصی آرتبوک‌های تجسمی',
                  descEn: 'Specialized visual arts & cinema books',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className={`p-3.5 rounded-2xl border md:backdrop-blur-xs ${
                    isDark
                      ? 'bg-gradient-to-b from-neutral-800/70 via-neutral-900/50 to-neutral-950/70 border-white/10'
                      : 'bg-gradient-to-b from-white via-neutral-50/90 to-neutral-100/80 border-neutral-300/80 shadow-xs'
                  }`}
                >
                  <div className="font-bold text-[#ee2524] mb-1">
                    {lang === 'fa' ? item.titleFa : item.titleEn}
                  </div>
                  <div className={`text-xs ${isDark ? 'text-neutral-300' : 'text-neutral-600'}`}>
                    {lang === 'fa' ? item.descFa : item.descEn}
                  </div>
                </div>
              ))}
            </div>

            <div>
              <button
                onClick={() => setShowFullStoryModal(true)}
                className={`inline-flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium transition-colors cursor-pointer md:backdrop-blur-xs ${
                  isDark
                    ? 'border-white/15 hover:bg-white/10 text-white'
                    : 'border-black/10 hover:bg-black/5 text-neutral-800'
                }`}
              >
                <BookOpen className="w-4 h-4 text-[#ee2524]" />
                <span>{t.readMoreStory}</span>
              </button>
            </div>
          </div>
        </div>

        {/* SPECIALIZED TEAM SHOWCASE */}
        <div id="team" className="pt-10">
          <div className="max-w-2xl mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold tracking-tight mb-2">
              {t.teamTitle}
            </h3>
            <p className={`text-sm sm:text-base ${isDark ? 'text-neutral-300' : 'text-neutral-600'}`}>
              {t.teamSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {TEAM_MEMBERS.map((member, idx) => {
              const name = lang === 'fa' ? member.nameFa : member.nameEn;
              const role = lang === 'fa' ? member.roleFa : member.roleEn;
              const bio = lang === 'fa' ? member.bioFa : member.bioEn;
              const specialty = lang === 'fa' ? member.specialtyFa : member.specialtyEn;

              return (
                <div
                  key={member.id}
                  className={`p-6 rounded-2xl border flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl md:backdrop-blur-xs ${
                    isDark
                      ? 'bg-gradient-to-b from-neutral-800/80 via-neutral-900/70 to-neutral-950/90 border-white/15 hover:border-white/30 text-white shadow-black/40'
                      : 'bg-gradient-to-b from-white via-neutral-50/90 to-neutral-100/80 border-neutral-300/80 hover:border-neutral-400 text-[#0D0D0D] shadow-md shadow-neutral-200/50'
                  }`}
                >
                  <div>
                    {/* Avatar Icon */}
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 border md:backdrop-blur-xs ${
                        isDark
                          ? 'bg-white/5 border-white/10 text-[#ee2524]'
                          : 'bg-white border-neutral-300/70 text-[#ee2524] shadow-xs'
                      }`}
                    >
                      <User className="w-7 h-7" />
                    </div>

                    <h4 className="font-bold text-lg mb-1">{name}</h4>
                    <p className="text-xs font-semibold text-[#ee2524] mb-3">{role}</p>
                    <p className={`text-xs leading-relaxed mb-4 ${isDark ? 'text-neutral-300' : 'text-neutral-600'}`}>
                      {bio}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-dashed border-neutral-700/30 dark:border-neutral-700/60 text-[11px] font-mono text-[#999999]">
                    {specialty}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* FULL MANIFESTO MODAL */}
      {showFullStoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 md:backdrop-blur-md">
          <div
            className={`relative max-w-3xl w-full rounded-3xl border p-6 sm:p-10 max-h-[85vh] overflow-y-auto md:backdrop-blur-2xl transition-all duration-200 ${
              isDark ? 'bg-neutral-900 border-white/15 text-white' : 'bg-white border-neutral-200 text-[#0D0D0D]'
            }`}
          >
            <button
              onClick={() => setShowFullStoryModal(false)}
              className="absolute top-4 right-4 p-2 rounded-full border border-neutral-700 text-neutral-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-6">
              <KarxaneMark className="w-8 h-12 text-current" />
              <div>
                <h3 className="text-xl sm:text-2xl font-bold">
                  {lang === 'fa' ? 'مانیفست استودیو کارخانه شیراز' : 'Studio Kārxāne Shiraz Manifesto'}
                </h3>
                <p className="text-xs text-[#ee2524] font-mono">EST. 1405 SHIRAZ</p>
              </div>
            </div>

            <div className="space-y-5 text-sm sm:text-base leading-relaxed mb-8">
              <p className="font-semibold text-lg text-[#ee2524]">
                {lang === 'fa'
                  ? 'کارخانه در سال ۱۴۰۵ از دل یک نیاز واقعی در شیراز شکل گرفت؛ نبود یک مرکز تخصصی برای کسانی که با تصویر کار می‌کنند.'
                  : 'Karxane was established in 2026 (1405 SH) in Shiraz out of a genuine necessity: the lack of a dedicated specialized center for visual creators.'}
              </p>

              <p>
                {lang === 'fa'
                  ? 'جایی که بتوان تجهیزات را تهیه کرد، تعمیرات را سپرد، فیلم را ظهور و اسکن کرد و کتاب تخصصی پیدا کرد. در همین راستا «کارخانه» در ۴ فضای اصلی برای پاسخگویی به این نیازها خدمات ارائه می‌دهد:'
                  : 'A place where one could acquire gear, entrust repairs, develop and scan film, and discover specialized artbooks. Karxane answers these needs across four core spaces:'}
              </p>

              <div className="space-y-4 pl-4 pr-4 border-l-2 border-r-2 border-[#ee2524]/40 py-2 my-4">
                <div>
                  <h5 className="font-bold text-[#ee2524] mb-1">
                    {lang === 'fa' ? '۱. تعمیرخانه' : '1. Repair Lab'}
                  </h5>
                  <p className="text-xs sm:text-sm">
                    {lang === 'fa'
                      ? 'تعمیر، سرویس و کالیبراسیون دوربین، لنز، تجهیزات نور، صدا و سایر تجهیزات تصویر؛ از دوربین‌های آنالوگ قدیمی تا تجهیزات دیجیتال روز. تعمیرخانه نمایندگی رسمی سیرنگ سرویس در شیراز است و تمام تعمیرات با برگه‌ی وضعیت عیب‌یابی و ۳ ماه ضمانت کتبی ارائه می‌شوند.'
                      : 'Repair, servicing, and calibration for cameras, lenses, lighting, and sound equipment — from vintage analog cameras to modern cinema systems. Official Sirang Service authorized agent in Shiraz with diagnostic sheets and 3 months of written guarantee.'}
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-[#ee2524] mb-1">
                    {lang === 'fa' ? '۲. تاریکخانه' : '2. Darkroom'}
                  </h5>
                  <p className="text-xs sm:text-sm">
                    {lang === 'fa'
                      ? 'فروش فیلم عکاسی، ظهور و اسکن نگاتیو، خرید و فروش دوربین‌ها، لنزها و تجهیزات آنالوگ. تاریکخانه برای کسانی است که با عکاسی آنالوگ کار می‌کنند؛ از کسانی که تازه می‌خواهند عکاسی آنالوگ را تجربه کنند تا عکاسانی که سال‌هاست نگاتیو بخشی از مسیر کاری‌شان است.'
                      : 'Film sales, negative developing and scanning, buying and selling analog cameras and lenses. Built for analog practitioners from beginners to seasoned artists.'}
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-[#ee2524] mb-1">
                    {lang === 'fa' ? '۳. کارخانه' : '3. Equipment Hub'}
                  </h5>
                  <p className="text-xs sm:text-sm">
                    {lang === 'fa'
                      ? 'تأمین تجهیزات عکاسی، فیلمبرداری و صدا، نو و کارکرده. برای انتخاب تجهیزات می‌توانید قبل از خرید، مشاوره بگیرید تا متناسب با نیاز و بودجه‌تان بهترین گزینه را انتخاب کنید. کالاهای نو با ضمانت معتبر تهیه می‌شوند و تجهیزات کارکرده هم پیش از فروش بررسی، سرویس و در صورت نیاز تعمیر شده و همراه با برگه‌ی مشخصات، وضعیت دستگاه و ۳ ماه ضمانت کتبی تحویل داده می‌شوند.'
                      : 'Procurement of photo, video, and audio gear, new and certified pre-owned. Gear consultation, official brand warranties for new gear, and full diagnostics for pre-owned equipment.'}
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-[#ee2524] mb-1">
                    {lang === 'fa' ? '۴. کتابخانه' : '4. Artbook Library'}
                  </h5>
                  <p className="text-xs sm:text-sm">
                    {lang === 'fa'
                      ? 'کتابفروشی تخصصی آرتبوک‌های عکاسی، سینما و هنرهای تجسمی. اگر کتاب یا نشریه‌ای که دنبالش هستید در قفسه‌های ما نباشد، امکان سفارش و تهیه‌ی منابع تخصصی مرتبط با تصویر وجود دارد. کتاب هم مثل دوربین، ابزار کار است، برای بهتر دیدن و بهتر ثبت کردن!'
                      : 'Curated bookstore for photography, cinema, and visual arts artbooks. Custom sourcing of international art publications. A book, just like a camera, is an essential tool — for seeing better and capturing deeper!'}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setShowFullStoryModal(false)}
                className="px-6 py-2.5 rounded-xl bg-[#ee2524] text-white font-medium text-sm hover:bg-[#d41f1e] cursor-pointer shadow-lg shadow-[#ee2524]/20"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
