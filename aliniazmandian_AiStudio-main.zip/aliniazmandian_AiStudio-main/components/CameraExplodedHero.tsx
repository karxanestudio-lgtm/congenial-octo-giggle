'use client';

import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown } from 'lucide-react';

interface HeroProps {
  isDark?: boolean;
}

export function CameraExplodedHero({}: HeroProps) {
  const [isScrollHintVisible, setIsScrollHintVisible] = useState(true);
  const isVisibleRef = useRef(true);

  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const currentY =
            window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
          const nextVisible = currentY < 40;
          if (nextVisible !== isVisibleRef.current) {
            isVisibleRef.current = nextVisible;
            setIsScrollHintVisible(nextVisible);
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <section
      id="hero-section"
      className="relative min-h-screen min-h-[100lvh] flex flex-col justify-end px-4 sm:px-6 lg:px-8 pb-16 z-10 pointer-events-none"
    >
      {/* Red Scroll Down Guide Arrow */}
      <div
        className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-30 pointer-events-none flex flex-col items-center justify-center transition-opacity duration-300 ${
          isScrollHintVisible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="animate-bounce flex flex-col items-center">
          <ChevronDown
            className="w-6 h-6 text-[#ee2524] drop-shadow-[0_2px_10px_rgba(238,37,36,0.7)]"
            strokeWidth={2.5}
          />
        </div>
      </div>
    </section>
  );
}


