'use client';

import React from 'react';
import { TRANSLATIONS } from '@/lib/translations';
import { Language } from '@/types';
import { X, Sun, Moon, Globe, Check, Settings2 } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  isDark: boolean;
  onSetTheme: (dark: boolean) => void;
  onSetLang: (lang: Language) => void;
}

export function SettingsModal({
  isOpen,
  onClose,
  lang,
  isDark,
  onSetTheme,
  onSetLang,
}: SettingsModalProps) {
  const t = TRANSLATIONS[lang];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 md:backdrop-blur-sm">
      <div
        className={`relative max-w-md w-full rounded-2xl border p-6 sm:p-7 shadow-2xl md:backdrop-blur-md transition-all duration-200 ${
          isDark
            ? 'bg-neutral-900 md:bg-gradient-to-b md:from-neutral-900/95 md:via-neutral-900/90 md:to-neutral-950/95 border-white/15 text-white'
            : 'bg-white md:bg-gradient-to-b md:from-white/95 md:via-neutral-100/95 md:to-neutral-200/95 border-neutral-300 text-[#0D0D0D]'
        }`}
      >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-neutral-200 dark:border-neutral-800 mb-6">
            <div className="flex items-center gap-2.5">
              <div
                className={`p-2 rounded-lg ${
                  isDark ? 'bg-white/10 text-[#ee2524]' : 'bg-black/5 text-[#ee2524]'
                }`}
              >
                <Settings2 className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-lg">{t.settingsTitle}</h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg border border-neutral-700 text-neutral-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Theme selection */}
          <div className="mb-6">
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#999999] mb-3">
              {t.themeMode}
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => onSetTheme(true)}
                className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all cursor-pointer ${
                  isDark
                    ? 'border-[#ee2524] bg-neutral-800/80 text-white font-medium'
                    : 'border-neutral-300 bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                }`}
              >
                <Moon className="w-5 h-5 text-indigo-400" />
                <span className="text-xs">{t.themeDark}</span>
                {isDark && <Check className="w-3.5 h-3.5 text-[#ee2524]" />}
              </button>

              <button
                onClick={() => onSetTheme(false)}
                className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all cursor-pointer ${
                  !isDark
                    ? 'border-[#ee2524] bg-white text-neutral-900 font-medium shadow-xs'
                    : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:bg-neutral-800'
                }`}
              >
                <Sun className="w-5 h-5 text-amber-500" />
                <span className="text-xs">{t.themeLight}</span>
                {!isDark && <Check className="w-3.5 h-3.5 text-[#ee2524]" />}
              </button>
            </div>
          </div>

          {/* Language Selection */}
          <div className="mb-6">
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#999999] mb-3">
              {t.languageChoice}
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => onSetLang('fa')}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  lang === 'fa'
                    ? isDark
                      ? 'border-[#ee2524] bg-neutral-800/80 font-bold text-[#ee2524]'
                      : 'border-[#ee2524] bg-white font-bold text-[#ee2524] shadow-xs'
                    : isDark
                    ? 'border-neutral-800 hover:bg-neutral-900 text-neutral-300'
                    : 'border-neutral-200 hover:bg-neutral-100 text-neutral-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-[#ee2524]" />
                  <span className="text-xs">فارسی (RTL)</span>
                </div>
                {lang === 'fa' && <Check className="w-3.5 h-3.5 text-[#ee2524]" />}
              </button>

              <button
                onClick={() => onSetLang('en')}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                  lang === 'en'
                    ? isDark
                      ? 'border-[#ee2524] bg-neutral-800/80 font-bold text-[#ee2524]'
                      : 'border-[#ee2524] bg-white font-bold text-[#ee2524] shadow-xs'
                    : isDark
                    ? 'border-neutral-800 hover:bg-neutral-900 text-neutral-300'
                    : 'border-neutral-200 hover:bg-neutral-100 text-neutral-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-[#ee2524]" />
                  <span className="text-xs">English (LTR)</span>
                </div>
                {lang === 'en' && <Check className="w-3.5 h-3.5 text-[#ee2524]" />}
              </button>
            </div>
          </div>

          {/* Close button */}
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-[#ee2524] text-white font-medium text-xs hover:bg-[#d41f1e] transition-colors cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
  );
}
