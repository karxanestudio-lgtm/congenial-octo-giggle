'use client';

import React from 'react';
import { ThreeCameraScene } from './ThreeCameraScene';

interface GlobalExplodedCameraBackgroundProps {
  isDark: boolean;
}

export function GlobalExplodedCameraBackground({ isDark }: GlobalExplodedCameraBackgroundProps) {
  return (
    <div
      className="fixed inset-0 w-full h-full pointer-events-none z-0 overflow-hidden select-none"
      style={{ height: '100%', minHeight: '100lvh' }}
      aria-hidden="true"
      suppressHydrationWarning
    >
      {/* 1. Base Studio Atmosphere Tone with Transparent Light Gray Gradient */}
      <div
        className={`absolute inset-0 transition-colors duration-700 ${
          isDark
            ? 'bg-gradient-to-b from-[#161616] via-[#101010] to-[#0A0A0A]'
            : 'bg-gradient-to-b from-[#F7F6F3] via-[#EFECE6]/80 to-[#E6E2DA]/90'
        }`}
      />

      {/* Transparent Light Gray Studio Overlay Gradient */}
      <div
        className={`absolute inset-0 pointer-events-none transition-opacity duration-700 ${
          isDark
            ? 'bg-gradient-to-b from-neutral-800/10 via-transparent to-black/40'
            : 'bg-gradient-to-b from-neutral-300/30 via-neutral-200/15 to-neutral-400/25'
        }`}
      />

      {/* 2. Soft Ambient Red & White Blooms (Fast Zero-Blur GPU Radial Gradients) */}
      <div
        className="absolute top-1/4 -right-20 w-[350px] sm:w-[550px] h-[350px] sm:h-[550px] rounded-full pointer-events-none opacity-70"
        style={{
          background: 'radial-gradient(circle, rgba(238,37,36,0.22) 0%, rgba(238,37,36,0) 70%)',
        }}
      />
      <div
        className="absolute bottom-1/4 -left-24 w-[400px] sm:w-[650px] h-[400px] sm:h-[650px] rounded-full pointer-events-none"
        style={{
          background: isDark
            ? 'radial-gradient(circle, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0) 70%)'
            : 'radial-gradient(circle, rgba(0,0,0,0.08) 0%, rgba(0,0,0,0) 70%)',
        }}
      />

      {/* 3. 3D Perspective Technical "Repair Mat" - Highly Optimized for Mobile GPU */}
      <div
        className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none"
        style={{ perspective: '1100px', perspectiveOrigin: '50% 48%' }}
      >
        <div
          style={{
            transform: 'rotateX(52deg) translateZ(0)',
            transformStyle: 'preserve-3d',
            WebkitBackfaceVisibility: 'hidden',
            backfaceVisibility: 'hidden',
          }}
          className="relative w-[180vw] h-[1800px] min-w-[1800px] min-h-[1800px] flex items-center justify-center pointer-events-none opacity-80"
        >
          {/* Main Repair Mat Vector Grid & Calibration Target Graphics */}
          <svg
            className="w-full h-full"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 1800 1800"
            fill="none"
          >
            <defs>
              {/* Secondary fine grid (80px) */}
              <pattern id="repair-mat-sub" width="80" height="80" patternUnits="userSpaceOnUse">
                <path
                  d="M 80 0 L 0 0 0 80"
                  fill="none"
                  stroke={isDark ? 'rgba(255,255,255,0.025)' : 'rgba(0,0,0,0.03)'}
                  strokeWidth="1"
                />
                <circle
                  cx="40"
                  cy="40"
                  r="1.2"
                  fill={isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)'}
                />
              </pattern>

              {/* Large primary grid (160px) with subtle red lines */}
              <pattern id="repair-mat-major" width="320" height="320" patternUnits="userSpaceOnUse">
                <rect width="320" height="320" fill="url(#repair-mat-sub)" />
                {/* Major White Grid Line */}
                <path
                  d="M 320 0 L 0 0 0 320"
                  fill="none"
                  stroke={isDark ? 'rgba(255,255,255,0.045)' : 'rgba(0,0,0,0.05)'}
                  strokeWidth="1.5"
                />
                {/* Large Red Grid Lines (#ee2524) */}
                <path
                  d="M 160 0 L 160 320 M 0 160 L 320 160"
                  fill="none"
                  stroke="rgba(238,37,36,0.075)"
                  strokeWidth="1.2"
                  strokeDasharray="8 6"
                />
                {/* Crosshair alignment markers at intersections */}
                <path
                  d="M 152 160 L 168 160 M 160 152 L 160 168"
                  stroke="rgba(238,37,36,0.14)"
                  strokeWidth="1.2"
                />
              </pattern>
            </defs>

            {/* Background Grid Fill */}
            <rect width="100%" height="100%" fill="url(#repair-mat-major)" />

            {/* Central Optical Calibration concentric circles (Repair Mat Target) */}
            <g transform="translate(900, 900)">
              {/* Concentric rings in subtle white and red */}
              <circle
                r="160"
                stroke={isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)'}
                strokeWidth="1.2"
                strokeDasharray="4 4"
              />
              <circle
                r="280"
                stroke="rgba(238,37,36,0.08)"
                strokeWidth="1.5"
              />
              <circle
                r="420"
                stroke={isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.05)'}
                strokeWidth="1.2"
                strokeDasharray="8 8"
              />
              <circle
                r="580"
                stroke="rgba(238,37,36,0.07)"
                strokeWidth="1.5"
                strokeDasharray="12 8"
              />
              <circle
                r="760"
                stroke={isDark ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.04)'}
                strokeWidth="1.2"
              />

              {/* Diagonal 45° and 30° Angular Alignment Rays */}
              <line x1="-780" y1="-780" x2="780" y2="780" stroke="rgba(238,37,36,0.04)" strokeWidth="1" strokeDasharray="6 6" />
              <line x1="-780" y1="780" x2="780" y2="-780" stroke="rgba(238,37,36,0.04)" strokeWidth="1" strokeDasharray="6 6" />

              {/* Faint Technical Work-Mat Labels */}
              <text
                x="0"
                y="-300"
                textAnchor="middle"
                fontSize="12"
                fontFamily="monospace"
                letterSpacing="4"
                fill="rgba(238,37,36,0.12)"
              >
                {'// OPTICAL BENCH REPAIR MAT • CALIBRATION MATRIX //'}
              </text>
              <text
                x="0"
                y="320"
                textAnchor="middle"
                fontSize="11"
                fontFamily="monospace"
                letterSpacing="3"
                fill={isDark ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.1)'}
              >
                [ SIRANG CAMERA & OPTICS WORKBENCH • STATION 01 SHIRAZ ]
              </text>

              {/* Component Staging Zones */}
              <rect
                x="-680"
                y="-550"
                width="280"
                height="180"
                rx="6"
                stroke="rgba(238,37,36,0.08)"
                strokeWidth="1"
                strokeDasharray="4 4"
                fill="none"
              />
              <text
                x="-540"
                y="-530"
                textAnchor="middle"
                fontSize="10"
                fontFamily="monospace"
                fill="rgba(238,37,36,0.14)"
              >
                LENS APERTURE ZONE
              </text>

              <rect
                x="400"
                y="-550"
                width="280"
                height="180"
                rx="6"
                stroke={isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)'}
                strokeWidth="1"
                strokeDasharray="4 4"
                fill="none"
              />
              <text
                x="540"
                y="-530"
                textAnchor="middle"
                fontSize="10"
                fontFamily="monospace"
                fill={isDark ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.1)'}
              >
                SENSOR & SHUTTER TRAY
              </text>

              <rect
                x="-680"
                y="380"
                width="280"
                height="160"
                rx="6"
                stroke={isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)'}
                strokeWidth="1"
                strokeDasharray="4 4"
                fill="none"
              />
              <text
                x="-540"
                y="400"
                textAnchor="middle"
                fontSize="10"
                fontFamily="monospace"
                fill={isDark ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.1)'}
              >
                SCREW MATRIX M1.2 - M2.0
              </text>
            </g>
          </svg>
        </div>
      </div>

      {/* 4. REAL 3D CAMERA MODEL ENGINE (Three.js WebGL with #999999 Fine Quad Grid & Exploded Optics) */}
      <ThreeCameraScene isDark={isDark} />
    </div>
  );
}
