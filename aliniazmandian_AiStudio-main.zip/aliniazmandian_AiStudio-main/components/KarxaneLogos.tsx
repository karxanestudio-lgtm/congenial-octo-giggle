'use client';

import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

/**
 * Geometric Brandmark from user's logo.png
 * - Signature red dot (#ee2524) at top-left
 * - Dynamic mechanical/architectural black geometric cuts (adapts to light/dark)
 */
export function KarxaneMark({ className = 'w-10 h-14', size }: LogoProps) {
  return (
    <svg
      viewBox="0 0 120 180"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 transition-transform duration-300 ${className}`}
      style={size ? { width: size, height: size * 1.5 } : undefined}
      aria-label="Studio Karxane Logo"
    >
      {/* Top Left Red Dot */}
      <circle cx="34" cy="27" r="16" fill="#ee2524" />

      {/* Top Right Angled Blade */}
      <path
        d="M62 65L120 15V0H84C72 0 64 6 62 18L62 65Z"
        fill="currentColor"
      />

      {/* Middle Left Angled Shutter Blade */}
      <path
        d="M0 65L58 116V130C58 120 52 110 40 102L0 76V65Z"
        fill="currentColor"
      />

      {/* Right Column (Rounded Top-Right) */}
      <path
        d="M62 72H102C112 72 120 80 120 90V180H62V72Z"
        fill="currentColor"
      />

      {/* Bottom Left Base Block (Rounded Top-Left) */}
      <path
        d="M18 134H56V180H0V152C0 142 8 134 18 134Z"
        fill="currentColor"
      />
    </svg>
  );
}

/**
 * English Logotype matching user's uploaded logotype-english.png: "Studio Kārxāne"
 * - Title case: "Studio Kārxāne"
 * - Ultra-bold geometric typography (Outfit 900)
 * - Monochromatic: crisp white in dark mode, deep black in light mode
 */
export function KarxaneLogotypeEnglish({
  className = '',
  isDark = true,
}: {
  className?: string;
  isDark?: boolean;
}) {
  return (
    <div
      className={`inline-flex items-center justify-center select-none transition-colors duration-200 ${
        isDark ? 'text-white' : 'text-[#0D0D0D]'
      } ${className}`}
      style={{
        fontFamily: "'Outfit', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      }}
    >
      <span className="font-[900] text-xl sm:text-2xl md:text-[27px] tracking-[-0.035em] leading-none whitespace-nowrap">
        Studio K&#257;rx&#257;ne
      </span>
    </div>
  );
}

/**
 * Persian Logotype matching user's logotype-persian.png: "استودیو کارخانه"
 * Designed in authentic heavy geometric Iranian display typography
 */
export function KarxaneLogotypePersian({ className = 'h-7', isDark = true }: { className?: string; isDark?: boolean }) {
  return (
    <div
      className={`inline-flex items-center select-none ${
        isDark ? 'text-white' : 'text-[#0D0D0D]'
      } ${className}`}
      dir="rtl"
    >
      <div className="flex items-center gap-2">
        <span
          className="text-xl md:text-2xl font-extrabold tracking-tight"
          style={{ fontFamily: 'Vazirmatn, sans-serif' }}
        >
          <span>استودیو</span>
          <span className="mr-1.5 text-[#ee2524]">کارخانه</span>
        </span>
      </div>
    </div>
  );
}

/**
 * Master Header Brand Component displaying:
 * - Geometric Logo Mark with red dot
 * - Both Persian & English logotypes side-by-side or stacked cleanly
 */
export function KarxaneHeaderBrand({
  isDark = true,
  currentLang = 'fa',
  className = '',
}: {
  isDark?: boolean;
  currentLang?: 'fa' | 'en';
  className?: string;
}) {
  return (
    <div className={`flex items-center gap-3 md:gap-4.5 text-current ${className}`}>
      {/* Brand Icon Mark */}
      <div className="relative group cursor-pointer">
        <KarxaneMark
          className="w-7 h-10 md:w-9 md:h-12 text-current transition-transform duration-300 group-hover:scale-105"
        />
      </div>

      {/* Dual Logotypes */}
      <div className="flex flex-col justify-center gap-0.5">
        <div className="flex items-center gap-2 md:gap-3">
          {/* Persian Logotype */}
          <div className="flex items-center">
            <KarxaneLogotypePersian isDark={isDark} className="h-6" />
          </div>

          <span className="text-[#999999] opacity-40 font-light text-sm hidden sm:inline">|</span>

          {/* English Logotype */}
          <div className="hidden sm:flex items-center">
            <KarxaneLogotypeEnglish isDark={isDark} className="h-5.5 text-lg" />
          </div>
        </div>

        {/* Subtitle location badge */}
        <div className="flex items-center gap-2 text-[10px] md:text-[11px] tracking-wider text-[#999999] uppercase font-mono">
          <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ee2524] animate-pulse" />
          <span>{currentLang === 'fa' ? 'شیراز ۱۴۰۵ • مرکز تخصصی تصویر' : 'Shiraz 2026 • Visual Arts & Optical Hub'}</span>
        </div>
      </div>
    </div>
  );
}
