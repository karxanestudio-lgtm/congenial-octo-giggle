'use client';

import React from 'react';
import Link from 'next/link';
import { KarxaneMark } from './KarxaneLogos';
import { TRANSLATIONS } from '@/lib/translations';
import { Language } from '@/types';
import { ArrowUp, MapPin, Phone, Mail, Instagram, Send, ShieldCheck } from 'lucide-react';

interface FooterProps {
  lang: Language;
  isDark: boolean;
}

export function Footer({ lang, isDark }: FooterProps) {
  const t = TRANSLATIONS[lang];

  const scrollToTop = () => {
    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
    window.scrollTo({ top: 0, behavior: isMobile ? 'auto' : 'smooth' });
  };

  return (
    <footer
      id="main-footer"
      className={`relative z-10 border-t transition-colors duration-300 backdrop-blur-none md:backdrop-blur-md ${
        isDark
          ? 'bg-gradient-to-b from-neutral-850/60 via-neutral-900/60 to-neutral-950/60 border-white/15 text-white'
          : 'bg-gradient-to-b from-white/60 via-neutral-50/60 to-neutral-100/60 border-neutral-300/40 text-[#0D0D0D]'
      }`}
    >
      {/* Top red accent line */}
      <div className="h-0.5 w-full bg-gradient-to-r from-transparent via-[#ee2524] to-transparent opacity-80" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-10 mb-12">
          {/* Brand & Mission Column (5 Cols) - ONLY LOGO MARK, NO LOGOTYPE */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              {/* Only the clean KarxaneMark logo */}
              <div className="mb-5 flex items-center gap-3">
                <div className={`p-3 rounded-2xl border md:backdrop-blur-md ${
                  isDark ? 'bg-white/5 border-white/10' : 'bg-white border-neutral-300/70 shadow-sm'
                }`}>
                  <KarxaneMark className="w-8 h-11 text-current" />
                </div>
                <div className="font-mono text-xs text-[#ee2524] tracking-widest uppercase font-semibold">
                  {lang === 'fa' ? 'استودیو کارخانه' : 'Studio Kārxāne'}
                </div>
              </div>

              <p className={`text-xs sm:text-sm leading-relaxed max-w-sm mb-5 ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                {t.footerBio}
              </p>

              {/* Sirang Service Agency Badge */}
              <div
                className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-mono mb-6 md:backdrop-blur-md ${
                  isDark
                    ? 'bg-neutral-900/90 md:bg-black/40 border-[#ee2524]/40 text-neutral-200'
                    : 'bg-gradient-to-r from-white via-white to-neutral-100/90 border-[#ee2524]/40 text-neutral-800 shadow-xs'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-[#ee2524]" />
                <span>
                  {lang === 'fa'
                    ? 'نمایندگی رسمی سیرنگ سرویس در شیراز • ۳ ماه ضمانت کتبی'
                    : 'Official Sirang Service Shiraz • 3-Month Written Warranty'}
                </span>
              </div>
            </div>

            {/* Social media connections */}
            <div className="flex items-center gap-2.5">
              {[
                { icon: <Instagram className="w-4 h-4" />, label: 'Instagram', href: 'https://instagram.com' },
                { icon: <Send className="w-4 h-4" />, label: 'Telegram', href: 'https://t.me' },
                { icon: <Mail className="w-4 h-4" />, label: 'Email', href: 'mailto:info@studiokarxane.ir' },
              ].map((item, idx) => (
                <a
                  key={idx}
                  href={item.href}
                  target="_blank"
                  rel="noreferrer"
                  className={`p-2.5 rounded-xl border md:backdrop-blur-md transition-colors ${
                    isDark
                      ? 'border-white/10 bg-neutral-900 md:bg-black/30 hover:bg-black/50 text-neutral-300 hover:text-white'
                      : 'border-neutral-300/80 bg-white hover:bg-neutral-100 text-neutral-700 hover:text-black shadow-xs'
                  }`}
                  aria-label={item.label}
                >
                  {item.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Studio Spaces Column (4 Cols) - "فضاهای استودیو کارخانه" (NO Quick Navigation) */}
          <div className="lg:col-span-4">
            <h4 className="font-bold text-sm uppercase tracking-wider text-[#ee2524] mb-4">
              {lang === 'fa' ? 'فضاهای استودیو کارخانه' : 'Studio Karxane Spaces'}
            </h4>
            <ul className="space-y-3 text-xs sm:text-sm">
              <li>
                <a href="#departments" className="hover:text-[#ee2524] transition-colors flex items-center gap-2">
                  <span className="text-[#ee2524] font-mono text-xs">۰۱.</span>
                  <span>{lang === 'fa' ? 'تعمیرخانه (سیرنگ سرویس با ۳ ماه ضمانت)' : 'Repair Lab (Sirang Service 3-Month Warranty)'}</span>
                </a>
              </li>
              <li>
                <a href="#departments" className="hover:text-[#ee2524] transition-colors flex items-center gap-2">
                  <span className="text-[#ee2524] font-mono text-xs">۰۲.</span>
                  <span>{lang === 'fa' ? 'تاریکخانه (ظهور، اسکن نگاتیو و فیلم)' : 'Darkroom (Film Dev & 48-bit Scan)'}</span>
                </a>
              </li>
              <li>
                <Link
                  href="/products"
                  className="hover:text-[#ee2524] transition-colors flex items-center gap-2 group cursor-pointer"
                >
                  <span className="text-[#ee2524] font-mono text-xs">۰۳.</span>
                  <span className="group-hover:text-[#ee2524] transition-colors">
                    {lang === 'fa' ? 'کارخانه (تأمین تجهیزات نو و کارکرده)' : 'Equipment Hub (New & Pre-Owned Gear)'}
                  </span>
                </Link>
              </li>
              <li>
                <a href="#departments" className="hover:text-[#ee2524] transition-colors flex items-center gap-2">
                  <span className="text-[#ee2524] font-mono text-xs">۰۴.</span>
                  <span>{lang === 'fa' ? 'کتابخانه (کتابفروشی تخصصی آرتبوک)' : 'Artbook Library (Visual Arts Publications)'}</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Shiraz Contact Summary (3 Cols) */}
          <div className="lg:col-span-3">
            <div className={`space-y-3 text-xs leading-relaxed ${isDark ? 'text-neutral-300' : 'text-neutral-600'}`}>
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#ee2524] shrink-0 mt-0.5" />
                <span>{t.addressText}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#ee2524] shrink-0" />
                <span className="font-mono">{t.phoneText}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Back to top */}
        <div className="pt-6 border-t border-neutral-700/30 dark:border-neutral-700/50 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className={isDark ? 'text-neutral-400' : 'text-neutral-500'}>
            {t.copyright}
          </div>

          <button
            onClick={scrollToTop}
            className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl border backdrop-blur-none md:backdrop-blur-md transition-colors cursor-pointer ${
              isDark
                ? 'border-white/10 bg-black/30 hover:bg-black/50 text-neutral-300'
                : 'border-black/5 bg-white/60 hover:bg-white/90 text-neutral-700 shadow-xs'
            }`}
          >
            <span>{lang === 'fa' ? 'بازگشت به بالا' : 'Back to top'}</span>
            <ArrowUp className="w-3.5 h-3.5 text-[#ee2524]" />
          </button>
        </div>
      </div>
    </footer>
  );
}
