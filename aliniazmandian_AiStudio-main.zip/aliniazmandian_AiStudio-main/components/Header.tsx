'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { KarxaneLogotypeEnglish, KarxaneMark, KarxaneLogotypePersian } from './KarxaneLogos';
import { Language } from '@/types';
import { Camera } from 'lucide-react';

interface HeaderProps {
  lang: Language;
  isDark: boolean;
  onOpenSettings: () => void;
}

/**
 * Minimalist Camera Recording Settings Button:
 * Pure simple red circle that pulses on and off smoothly with no white border or inner dot
 */
function CameraShutterButton({
  onClick,
  lang,
}: {
  onClick: () => void;
  lang: Language;
}) {
  return (
    <div className="flex items-center gap-2">
      <button
        onClick={onClick}
        id="camera-shutter-settings-btn"
        className="relative flex items-center justify-center w-8 h-8 rounded-full cursor-pointer transition-transform duration-150 active:scale-90 focus:outline-none"
        title={lang === 'fa' ? 'تنظیمات زبان و تم' : 'Language & Theme Settings'}
        aria-label="Settings"
      >
        {/* Simple pure red circle that blinks / pulses on and off smoothly */}
        <div className="w-3.5 h-3.5 rounded-full bg-[#ee2524] shadow-sm shadow-[#ee2524]/60 animate-pulse" />
      </button>

      {/* Rec blink text label */}
      <div className="hidden sm:flex items-center">
        <span className="text-[10px] font-mono font-bold tracking-wider text-[#ee2524] uppercase select-none animate-pulse">
          REC
        </span>
      </div>
    </div>
  );
}

export function Header({
  lang,
  isDark,
  onOpenSettings,
}: HeaderProps) {
  const [isVisible, setIsVisible] = useState(true);
  const isVisibleRef = useRef(true);
  const lastScrollYRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (rafRef.current !== null) return;

      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = null;
        const currentScrollY = window.scrollY || window.pageYOffset || 0;
        const lastScrollY = lastScrollYRef.current;

        let nextVisible = isVisibleRef.current;
        if (currentScrollY < 60) {
          nextVisible = true;
        } else if (currentScrollY > lastScrollY + 8) {
          nextVisible = false;
        } else if (currentScrollY < lastScrollY - 8) {
          nextVisible = true;
        }

        if (nextVisible !== isVisibleRef.current) {
          isVisibleRef.current = nextVisible;
          setIsVisible(nextVisible);
        }
        lastScrollYRef.current = currentScrollY;
      });
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 bg-transparent ${
        isVisible ? 'translate-y-0' : '-translate-y-full'
      } ${
        isDark ? 'text-white' : 'text-[#0D0D0D]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative flex items-center justify-between h-18" dir="ltr">
          {/* LEFT SIDE (Settings / Pure Red Record Button + Gear Showcase Link) */}
          <div className="flex items-center gap-3 shrink-0">
            <CameraShutterButton
              onClick={onOpenSettings}
              lang={lang}
            />

            {/* Link to Dedicated Products Page */}
            <Link
              href="/products"
              className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border backdrop-blur-md transition-all duration-150 cursor-pointer ${
                isDark
                  ? 'bg-neutral-900/40 hover:bg-neutral-800/60 border-neutral-700/50 text-neutral-300 hover:text-white'
                  : 'bg-white/40 hover:bg-white/70 border-neutral-300/60 text-neutral-700 hover:text-black shadow-xs'
              }`}
            >
              <Camera className="w-3.5 h-3.5 text-[#ee2524]" />
              <span>{lang === 'fa' ? 'ویترین تجهیزات' : 'Gear Showcase'}</span>
            </Link>
          </div>

          {/* CENTER: Studio Kārxāne Logotype - Exactly centered horizontally & vertically */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center pointer-events-auto">
            <Link
              href="/"
              className="no-underline outline-none transition-transform hover:scale-[1.02] flex items-center justify-center cursor-pointer p-1"
              title={lang === 'fa' ? 'صفحه اصلی استودیو کارخانه' : 'Studio Kārxāne Landing Page'}
            >
              <KarxaneLogotypeEnglish
                isDark={isDark}
                className="tracking-tight"
              />
            </Link>
          </div>

          {/* RIGHT SIDE: Karxane Emblem & Persian Logotype */}
          <div className="flex items-center gap-2.5 shrink-0" dir="rtl">
            <Link href="/" className="flex items-center gap-2.5 group no-underline text-current">
              <KarxaneMark className="w-6 h-8 sm:w-7 sm:h-10 transition-transform group-hover:scale-105" />
              <span className="hidden sm:inline-block">
                <KarxaneLogotypePersian isDark={isDark} className="h-6" />
              </span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}

