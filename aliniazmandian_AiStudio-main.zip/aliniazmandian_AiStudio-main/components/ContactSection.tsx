'use client';

import React, { useState } from 'react';
import { TRANSLATIONS } from '@/lib/translations';
import { Language } from '@/types';
import { MapPin, Phone, Clock, Send, CheckCircle, MessageSquare } from 'lucide-react';

interface ContactSectionProps {
  lang: Language;
  isDark: boolean;
  prefilledGear?: string;
  prefilledService?: string;
}

export function ContactSection({
  lang,
  isDark,
  prefilledGear = '',
  prefilledService = '',
}: ContactSectionProps) {
  const t = TRANSLATIONS[lang];

  const [fullName, setFullName] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [serviceDept, setServiceDept] = useState(prefilledService || 'workshop');
  const [gearModel, setGearModel] = useState(prefilledGear || '');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Sync props when user clicks inquire from product card or department during render
  const [prevGear, setPrevGear] = useState(prefilledGear);
  const [prevService, setPrevService] = useState(prefilledService);

  if (prefilledGear !== prevGear) {
    setPrevGear(prefilledGear);
    setGearModel(prefilledGear);
  }
  if (prefilledService !== prevService) {
    setPrevService(prefilledService);
    setServiceDept(prefilledService || 'workshop');
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !contactInfo.trim()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setTimeout(() => {
        setFullName('');
        setContactInfo('');
        setGearModel('');
        setMessage('');
      }, 500);
    }, 900);
  };

  return (
    <section
      id="contact"
      className="py-24 relative z-10 bg-transparent transition-colors duration-300"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Information & Workshop Details (5 Cols) with Gray-to-Transparent Glassmorphism */}
          <div
            className={`lg:col-span-5 flex flex-col justify-between p-8 sm:p-10 rounded-3xl border md:backdrop-blur-xs shadow-xl transition-all duration-300 ${
              isDark
                ? 'bg-gradient-to-b from-neutral-800/90 via-neutral-900/80 to-neutral-950/95 border-white/15 text-white shadow-black/50'
                : 'bg-gradient-to-b from-white via-neutral-100/90 to-neutral-200/80 border-neutral-300/80 text-[#0D0D0D] shadow-xl shadow-neutral-300/40'
            }`}
          >
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
                {t.contactTitle}
              </h2>

              <p className={`text-base leading-relaxed mb-8 ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                {t.contactSubtitle}
              </p>

              {/* Shiraz Location details */}
              <div className="space-y-4">
                <div
                  className={`p-4 rounded-2xl border md:backdrop-blur-xs flex items-center gap-4 transition-colors ${
                    isDark
                      ? 'bg-gradient-to-b from-neutral-800/70 via-neutral-900/50 to-neutral-950/70 border-white/10'
                      : 'bg-gradient-to-b from-white via-neutral-50/90 to-neutral-100/80 border-neutral-300/80 shadow-xs'
                  }`}
                >
                  <div
                    className={`p-2.5 rounded-xl shrink-0 ${
                      isDark ? 'bg-white/10 text-[#ee2524]' : 'bg-white border border-neutral-300/60 text-[#ee2524] shadow-xs'
                    }`}
                  >
                    <MapPin className="w-5 h-5" />
                  </div>
                  <p className={`text-xs sm:text-sm leading-relaxed ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                    {t.addressText}
                  </p>
                </div>

                <div
                  className={`p-4 rounded-2xl border md:backdrop-blur-xs flex items-start gap-4 transition-colors ${
                    isDark
                      ? 'bg-gradient-to-b from-neutral-800/70 via-neutral-900/50 to-neutral-950/70 border-white/10'
                      : 'bg-gradient-to-b from-white via-neutral-50/90 to-neutral-100/80 border-neutral-300/80 shadow-xs'
                  }`}
                >
                  <div
                    className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                      isDark ? 'bg-white/10 text-[#ee2524]' : 'bg-white border border-neutral-300/60 text-[#ee2524] shadow-xs'
                    }`}
                  >
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm mb-1">{t.phoneTitle}</h4>
                    <p className={`text-xs sm:text-sm font-mono ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                      {t.phoneText}
                    </p>
                  </div>
                </div>

                <div
                  className={`p-4 rounded-2xl border md:backdrop-blur-xs flex items-start gap-4 transition-colors ${
                    isDark
                      ? 'bg-gradient-to-b from-neutral-800/70 via-neutral-900/50 to-neutral-950/70 border-white/10'
                      : 'bg-gradient-to-b from-white via-neutral-50/90 to-neutral-100/80 border-neutral-300/80 shadow-xs'
                  }`}
                >
                  <div
                    className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                      isDark ? 'bg-white/10 text-[#ee2524]' : 'bg-white border border-neutral-300/60 text-[#ee2524] shadow-xs'
                    }`}
                  >
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm mb-1">{t.hoursTitle}</h4>
                    <p className={`text-xs sm:text-sm ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                      {t.hoursText}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick message badge */}
            <div className="mt-8 pt-6 border-t border-dashed border-neutral-700/40 dark:border-neutral-700/60 flex items-center gap-2 text-xs text-[#999999]">
              <MessageSquare className="w-4 h-4 text-[#ee2524] shrink-0" />
              <span>
                {lang === 'fa'
                  ? 'امکان تحویل حضوری فیلم و تجهیزات در کارگاه شیراز با هماهنگی قبلی فراهم است.'
                  : 'In-person drop-off for film rolls and equipment at our Shiraz studio available.'}
              </span>
            </div>
          </div>

          {/* Form Container (7 Cols) with Gray-to-Transparent Glassmorphism */}
          <div className="lg:col-span-7">
            <div
              className={`p-6 sm:p-8 lg:p-10 rounded-3xl border shadow-xl relative overflow-hidden md:backdrop-blur-xs transition-all duration-300 ${
                isDark
                  ? 'bg-gradient-to-b from-neutral-800/90 via-neutral-900/80 to-neutral-950/95 border-white/15 text-white shadow-black/50'
                  : 'bg-gradient-to-b from-white via-neutral-100/90 to-neutral-200/80 border-neutral-300/80 text-[#0D0D0D] shadow-xl shadow-neutral-300/40'
              }`}
            >
              {isSuccess ? (
                <div
                  className="py-16 text-center flex flex-col items-center"
                >
                  <div className="w-16 h-16 rounded-full bg-[#ee2524]/10 text-[#ee2524] flex items-center justify-center mb-4">
                    <CheckCircle className="w-9 h-9" />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{t.formSubmittedTitle}</h3>
                  <p className={`text-sm max-w-sm mb-6 ${isDark ? 'text-neutral-300' : 'text-neutral-600'}`}>
                    {t.formSubmittedDesc}
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsSuccess(false)}
                    className="px-6 py-2.5 rounded-xl border border-neutral-700 text-xs font-semibold hover:bg-neutral-800 transition-colors cursor-pointer"
                  >
                    {lang === 'fa' ? 'ثبت درخواست جدید' : 'Submit Another Inquiry'}
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={handleSubmit}
                  className="space-y-5"
                >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Name */}
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider mb-2">
                          {t.formName} *
                        </label>
                        <input
                          type="text"
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder={lang === 'fa' ? 'مثال: رضا احمدی' : 'e.g. John Miller'}
                          className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all ${
                            isDark
                              ? 'bg-neutral-900/80 border-white/15 focus:border-[#ee2524] text-white'
                              : 'bg-white border-neutral-300 focus:border-[#ee2524] text-black'
                          }`}
                        />
                      </div>

                      {/* Phone / Contact */}
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider mb-2">
                          {t.formPhone} *
                        </label>
                        <input
                          type="text"
                          required
                          value={contactInfo}
                          onChange={(e) => setContactInfo(e.target.value)}
                          placeholder={lang === 'fa' ? '۰۹۱۲... یا آیدی تلگرام' : '+98 912... or Telegram handle'}
                          className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all ${
                            isDark
                              ? 'bg-neutral-900/80 border-white/15 focus:border-[#ee2524] text-white'
                              : 'bg-white border-neutral-300 focus:border-[#ee2524] text-black'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Space Subject */}
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider mb-2">
                          {t.formService}
                        </label>
                        <select
                          value={serviceDept}
                          onChange={(e) => setServiceDept(e.target.value)}
                          className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all cursor-pointer ${
                            isDark
                              ? 'bg-neutral-900 border-white/15 focus:border-[#ee2524] text-white'
                              : 'bg-white border-neutral-300 focus:border-[#ee2524] text-black'
                          }`}
                        >
                          <option value="repair">
                            {lang === 'fa' ? '۱. تعمیرخانه (تعمیر، کالیبراسیون و سرویس)' : '1. Repair Lab (Service & Calibration)'}
                          </option>
                          <option value="darkroom">
                            {lang === 'fa' ? '۲. تاریکخانه (ظهور، اسکن نگاتیو و فیلم)' : '2. Darkroom (Develop, Scan & Film)'}
                          </option>
                          <option value="workshop">
                            {lang === 'fa' ? '۳. کارخانه (خرید و استعلام تجهیزات)' : '3. Equipment Hub (Cameras & Gear)'}
                          </option>
                          <option value="library">
                            {lang === 'fa' ? '۴. کتابخانه (سفارش و خرید آرتبوک)' : '4. Artbook Library (Visual Books)'}
                          </option>
                        </select>
                      </div>

                      {/* Equipment Model / Title */}
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider mb-2">
                          {t.formGearModel}
                        </label>
                        <input
                          type="text"
                          value={gearModel}
                          onChange={(e) => setGearModel(e.target.value)}
                          placeholder={lang === 'fa' ? 'مثال: Leica M6 یا فیلم کداک تری-ایکس' : 'e.g. Leica M6 or Kodak Tri-X'}
                          className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all md:backdrop-blur-xs ${
                            isDark
                              ? 'bg-neutral-900/50 border-white/15 focus:border-[#ee2524] text-white'
                              : 'bg-white/80 border-neutral-300 focus:border-[#ee2524] text-black'
                          }`}
                        />
                      </div>
                    </div>

                    {/* Message Area */}
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider mb-2">
                        {t.formMessage}
                      </label>
                      <textarea
                        rows={4}
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder={
                          lang === 'fa'
                            ? 'شرح ایراد دستگاه، درخواست استعلام، رزرو نوبت عیب‌یابی یا سفارش کتاب...'
                            : 'Brief description of device malfunction, gear inquiry, or book title...'
                        }
                        className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all resize-none md:backdrop-blur-xs ${
                          isDark
                            ? 'bg-neutral-900/50 border-white/15 focus:border-[#ee2524] text-white'
                            : 'bg-white/80 border-neutral-300 focus:border-[#ee2524] text-black'
                        }`}
                      />
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 px-6 rounded-xl bg-[#ee2524] text-white font-medium text-sm flex items-center justify-center gap-2 hover:bg-[#d41f1e] active:scale-[0.99] transition-all duration-200 cursor-pointer shadow-lg shadow-[#ee2524]/25 disabled:opacity-50 md:backdrop-blur-md"
                    >
                      {isSubmitting ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>{t.formSubmit}</span>
                        </>
                      )}
                    </button>
                  </form>
                )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
