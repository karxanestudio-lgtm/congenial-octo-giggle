'use client';

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { buildProceduralDslrCamera, ExplodedCameraParts } from './camera-3d/ProceduralDslrBuilder';

interface ThreeCameraSceneProps {
  isDark: boolean;
}

export function ThreeCameraScene({ isDark }: ThreeCameraSceneProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Store references for external UI callbacks
  const cameraPartsRef = useRef<ExplodedCameraParts | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const isMobileViewport = () => {
      if (typeof window === 'undefined') return false;
      return window.innerWidth < 768;
    };

    // 1. Scene Setup
    const scene = new THREE.Scene();

    // 2. Camera Setup - Technical Perspective Viewport
    let lastWidth = container.clientWidth || window.innerWidth;
    let lastHeight = container.clientHeight || window.innerHeight;
    const camera = new THREE.PerspectiveCamera(30, lastWidth / lastHeight, 0.1, 100);
    camera.position.set(0, 0, 9.6);

    // 3. WebGL Renderer with Maximum Cross-Browser & Multi-Platform Optimization
    const isMobile = isMobileViewport();
    const maxPixelRatio = isMobile
      ? Math.min(window.devicePixelRatio || 1, 1.5)
      : Math.min(window.devicePixelRatio || 1, 2.0);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
      precision: isMobile ? 'mediump' : 'highp',
      stencil: false,
      depth: true,
      preserveDrawingBuffer: false,
    });
    renderer.setPixelRatio(maxPixelRatio);
    renderer.setSize(lastWidth, lastHeight, false);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.04;

    // Cross-Browser Hardware Acceleration CSS
    const canvas = renderer.domElement;
    canvas.style.touchAction = 'none';
    canvas.style.pointerEvents = 'none';
    canvas.style.transform = 'translate3d(0,0,0)';
    canvas.style.webkitTransform = 'translate3d(0,0,0)';
    canvas.style.backfaceVisibility = 'hidden';
    canvas.style.webkitBackfaceVisibility = 'hidden';
    canvas.style.display = 'block';
    canvas.style.position = 'absolute';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    container.appendChild(canvas);

    // WebGL Context Loss / Restore protection
    const handleContextLost = (e: Event) => {
      e.preventDefault();
    };
    canvas.addEventListener('webglcontextlost', handleContextLost, false);

    // 4. Build Procedural Precision DSLR Camera
    const cameraParts = buildProceduralDslrCamera(isDark);
    cameraPartsRef.current = cameraParts;
    scene.add(cameraParts.masterRig);

    // Master Rig Initial Transform (30% to left: -27°, 10° downward pitch)
    const masterRig = cameraParts.masterRig;
    masterRig.rotation.x = THREE.MathUtils.degToRad(10.0);
    masterRig.rotation.y = THREE.MathUtils.degToRad(-27.0);
    masterRig.position.set(0, -0.1, 0);

    const baseScale = isMobile ? 0.38 : 0.56;
    masterRig.scale.setScalar(baseScale);

    // Immediate synchronous first-frame render
    cameraParts.setExplosionProgress(0, isMobile);
    renderer.render(scene, camera);

    // 5. High-Performance Zero-Layout-Thrashing Scroll Tracking
    let maxScroll = 1;
    const recalculateMetrics = () => {
      const docHeight = Math.max(
        document.documentElement.scrollHeight,
        document.body.scrollHeight,
        1
      );
      const winHeight = window.innerHeight || document.documentElement.clientHeight || 1;
      maxScroll = Math.max(1, docHeight - winHeight);
    };
    recalculateMetrics();

    let targetScroll = Math.min(
      1,
      Math.max(0, (window.scrollY || window.pageYOffset || 0) / maxScroll)
    );
    let currentScroll = targetScroll;
    let animationFrameId: number;

    const handleWindowScroll = () => {
      const scrollY = window.scrollY || window.pageYOffset || 0;
      targetScroll = Math.min(1, Math.max(0, scrollY / maxScroll));
    };
    window.addEventListener('scroll', handleWindowScroll, { passive: true });

    // Direct Synchronous Render Frame
    const updateSceneForScroll = (s: number, mobile: boolean) => {
      const initialFacingLeftY = THREE.MathUtils.degToRad(-27.0);
      const scrollRotationY = initialFacingLeftY + s * Math.PI * 3.5;
      masterRig.rotation.y = scrollRotationY;

      const initialPitchX = THREE.MathUtils.degToRad(10.0);
      const dynamicPitchX = initialPitchX + Math.sin(s * Math.PI * 2) * 0.14;
      masterRig.rotation.x = dynamicPitchX;
      masterRig.rotation.z = Math.sin(s * Math.PI * 3) * 0.025;

      const scale = mobile ? 0.38 : 0.56;
      masterRig.scale.setScalar(scale);

      cameraParts.setExplosionProgress(s, mobile);
    };

    // 6. Continuous Smooth Render Loop (Adaptive Lerp to prevent mobile fling freeze & pop)
    const renderLoop = () => {
      animationFrameId = requestAnimationFrame(renderLoop);

      const mobile = isMobileViewport();
      const diff = targetScroll - currentScroll;
      const absDiff = Math.abs(diff);

      // Adaptive lerp: on fast inertial fling scrolls, catch up immediately so there is ZERO lag, freezing or post-scroll pop
      let lerpSpeed = mobile ? 0.35 : 0.14;
      if (mobile && absDiff > 0.04) {
        lerpSpeed = Math.min(0.85, 0.35 + absDiff * 1.6);
      }

      currentScroll += diff * lerpSpeed;
      if (absDiff < 0.0003) {
        currentScroll = targetScroll;
      }

      updateSceneForScroll(currentScroll, mobile);
      renderer.render(scene, camera);
    };

    animationFrameId = requestAnimationFrame(renderLoop);

    // 7. Responsive Viewport Sizing (Ignored for mobile address-bar vertical-only changes)
    let resizeRafId: number | null = null;
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      const mobile = isMobileViewport();

      // Crucial Fix: On mobile, address bar show/hide causes vertical height shifts of ~60-80px.
      // If width hasn't changed (no orientation change), do NOT recompute projection matrix or resize canvas!
      if (mobile && Math.abs(w - lastWidth) < 25) {
        return;
      }

      lastWidth = w;
      lastHeight = h;
      recalculateMetrics();

      if (resizeRafId !== null) cancelAnimationFrame(resizeRafId);
      resizeRafId = requestAnimationFrame(() => {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h, false);
      });
    };
    window.addEventListener('resize', handleResize, { passive: true });
    window.addEventListener('orientationchange', handleResize, { passive: true });

    // 8. Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      if (resizeRafId !== null) cancelAnimationFrame(resizeRafId);
      window.removeEventListener('scroll', handleWindowScroll);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
      canvas.removeEventListener('webglcontextlost', handleContextLost);

      cameraParts.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [isDark]);

  // Update materials when theme changes
  useEffect(() => {
    if (cameraPartsRef.current) {
      cameraPartsRef.current.updateMaterials(isDark);
    }
  }, [isDark]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full z-0 overflow-hidden select-none pointer-events-none cursor-default"
    />
  );
}
