'use client';

import React, { useState } from 'react';
import { DEPARTMENTS, TRANSLATIONS } from '@/lib/translations';
import { Language, Department } from '@/types';
import {
  Wrench,
  Flame,
  Camera,
  BookOpen,
  Check,
  ShieldCheck,
  ArrowRight,
  Award,
} from 'lucide-react';

interface DepartmentShowcaseProps {
  lang: Language;
  isDark: boolean;
  onRequestDepartmentService: (dept: Department) => void;
}

export function DepartmentShowcase({
  lang,
  isDark,
  onRequestDepartmentService,
}: DepartmentShowcaseProps) {
  const [activeDeptId, setActiveDeptId] = useState<string>('repair');
  const t = TRANSLATIONS[lang];

  const activeDept = DEPARTMENTS.find((d) => d.id === activeDeptId) || DEPARTMENTS[0];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Wrench':
        return <Wrench className="w-5 h-5" />;
      case 'Flame':
        return <Flame className="w-5 h-5" />;
      case 'Camera':
        return <Camera className="w-5 h-5" />;
      case 'BookOpen':
        return <BookOpen className="w-5 h-5" />;
      default:
        return <Camera className="w-5 h-5" />;
    }
  };

  return (
    <section
      id="departments"
      className="py-24 relative z-10 bg-transparent transition-colors duration-300"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header: چهار فضای استودیو کارخانه */}
        <div className="max-w-3xl mx-auto text-center mb-14">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight mb-4">
            {t.departmentsTitle}
          </h2>
          <p className={`text-base sm:text-lg leading-relaxed ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
            {t.departmentsSubtitle}
          </p>
        </div>

        {/* 4 Spaces Navigation Tabs with Glassmorphism (Numbers removed) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-8">
          {DEPARTMENTS.map((dept) => {
            const isActive = activeDeptId === dept.id;
            const title = lang === 'fa' ? dept.titleFa : dept.titleEn;
            const tagline = lang === 'fa' ? dept.taglineFa : dept.taglineEn;

            return (
              <button
                key={dept.id}
                onClick={() => setActiveDeptId(dept.id)}
                className={`p-4 sm:p-5 rounded-2xl border text-start transition-all duration-200 cursor-pointer flex flex-col justify-between md:backdrop-blur-xs ${
                  isActive
                    ? isDark
                      ? 'border-[#ee2524] bg-gradient-to-b from-neutral-800 via-neutral-900 to-neutral-950 shadow-lg shadow-black/40 scale-[1.02]'
                      : 'border-[#ee2524] bg-gradient-to-b from-white via-red-50/30 to-neutral-100/90 shadow-md shadow-neutral-300/40 scale-[1.02]'
                    : isDark
                    ? 'border-white/10 bg-gradient-to-b from-neutral-800/60 via-neutral-900/40 to-neutral-950/60 hover:border-white/25'
                    : 'border-neutral-300/80 bg-gradient-to-b from-white/95 via-neutral-50/80 to-neutral-100/60 hover:border-neutral-400 shadow-xs'
                }`}
              >
                <div className="flex items-center justify-end w-full mb-3">
                  <div
                    className={`p-2.5 rounded-xl transition-colors md:backdrop-blur-xs ${
                      isActive
                        ? 'bg-[#ee2524] text-white'
                        : isDark
                        ? 'bg-white/10 text-[#ee2524]'
                        : 'bg-black/5 text-[#ee2524]'
                    }`}
                  >
                    {getIcon(dept.icon)}
                  </div>
                </div>

                <div>
                  <h3 className={`font-bold text-base md:text-lg ${isActive ? 'text-[#ee2524]' : ''}`}>
                    {title}
                  </h3>
                  <p className="text-xs text-[#999999] line-clamp-1 mt-1 font-normal">
                    {tagline}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Space Content Showcase with Gray-to-Transparent Glassmorphism (Numbers removed) */}
        <div
          key={activeDept.id}
          className={`rounded-3xl border p-6 sm:p-8 lg:p-12 relative overflow-hidden md:backdrop-blur-sm transition-all duration-300 shadow-xl ${
            isDark
              ? 'bg-gradient-to-b from-neutral-800/90 via-neutral-900/80 to-neutral-950/95 border-white/15 text-white shadow-black/60'
              : 'bg-gradient-to-b from-white via-neutral-100/90 to-neutral-200/80 border-neutral-300/80 text-[#0D0D0D] shadow-xl shadow-neutral-300/40'
          }`}
        >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 relative z-10">
              {/* Left/Main Column */}
              <div className="lg:col-span-7 flex flex-col justify-between">
                <div>
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-[#ee2524] text-white mb-4 shadow-md shadow-[#ee2524]/20">
                    {getIcon(activeDept.icon)}
                    <span>{lang === 'fa' ? activeDept.titleFa : activeDept.titleEn}</span>
                  </div>

                  <h3 className="text-2xl sm:text-3xl font-bold tracking-tight mb-4 leading-snug">
                    {lang === 'fa' ? activeDept.taglineFa : activeDept.taglineEn}
                  </h3>

                  <p
                    className={`text-base sm:text-lg leading-relaxed mb-6 font-normal ${
                      isDark ? 'text-neutral-300' : 'text-neutral-700'
                    }`}
                  >
                    {lang === 'fa' ? activeDept.descriptionFa : activeDept.descriptionEn}
                  </p>

                  {/* Official Sirang / Service Notice Badge */}
                  {activeDept.serviceSheetNoticeFa && (
                    <div
                      className={`p-4 rounded-2xl border md:backdrop-blur-xs flex items-start gap-3 mb-6 ${
                        isDark
                          ? 'bg-gradient-to-b from-neutral-800/70 via-neutral-900/50 to-neutral-950/70 border-white/10 text-neutral-200'
                          : 'bg-gradient-to-b from-white via-neutral-50/90 to-neutral-100/80 border-neutral-300/80 text-neutral-800 shadow-xs'
                      }`}
                    >
                      <Award className="w-5 h-5 text-[#ee2524] shrink-0 mt-0.5" />
                      <div className="text-xs sm:text-sm font-medium">
                        {lang === 'fa'
                          ? activeDept.serviceSheetNoticeFa
                          : activeDept.serviceSheetNoticeEn}
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => onRequestDepartmentService(activeDept)}
                    className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#ee2524] text-white font-medium text-sm hover:bg-[#d41f1e] active:scale-95 transition-all shadow-lg shadow-[#ee2524]/25 cursor-pointer"
                  >
                    <span>
                      {lang === 'fa'
                        ? `هماهنگی و پذیرش ${activeDept.titleFa}`
                        : `Coordinate with ${activeDept.titleEn}`}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Right Column: Key Standards with Glassmorphism */}
              <div
                className={`lg:col-span-5 p-6 sm:p-7 rounded-2xl border md:backdrop-blur-xs flex flex-col justify-center ${
                  isDark
                    ? 'bg-gradient-to-b from-neutral-800/70 via-neutral-900/50 to-neutral-950/70 border-white/10'
                    : 'bg-gradient-to-b from-white via-neutral-50/90 to-neutral-100/80 border-neutral-300/80 shadow-xs'
                }`}
              >
                <h4 className="text-sm font-bold text-[#ee2524] uppercase tracking-wider mb-5 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  <span>
                    {lang === 'fa' ? 'استانداردها و خدمات شاخص:' : 'Core Standards & Capabilities:'}
                  </span>
                </h4>

                <ul className="space-y-4">
                  {(lang === 'fa' ? activeDept.highlightsFa : activeDept.highlightsEn).map(
                    (highlight, i) => (
                      <li key={i} className="flex items-start gap-3 text-xs sm:text-sm">
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                            isDark ? 'bg-white/10 text-[#ee2524]' : 'bg-black/5 text-[#ee2524]'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </div>
                        <span className={isDark ? 'text-neutral-300' : 'text-neutral-700'}>
                          {highlight}
                        </span>
                      </li>
                    )
                  )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
  );
}
