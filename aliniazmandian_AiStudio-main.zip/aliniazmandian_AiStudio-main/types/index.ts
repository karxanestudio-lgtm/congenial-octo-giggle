export type Language = 'fa' | 'en';
export type ThemeMode = 'dark' | 'light';

export interface Product {
  id: string;
  name: string;
  nameEn: string;
  type: 'analog' | 'digital' | 'accessory';
  categoryFa: string;
  categoryEn: string;
  condition: 'new' | 'preowned';
  conditionFa: string;
  conditionEn: string;
  priceTomans: number;
  priceUsd: number;
  image: string;
  badgeFa?: string;
  badgeEn?: string;
  descriptionFa?: string;
  descriptionEn?: string;
  specsFa: string[];
  specsEn: string[];
  diagnosticInfoFa: string;
  diagnosticInfoEn: string;
  warrantyFa: string;
  warrantyEn: string;
}

export interface Department {
  id: string;
  number: string;
  titleFa: string;
  titleEn: string;
  taglineFa: string;
  taglineEn: string;
  descriptionFa: string;
  descriptionEn: string;
  highlightsFa: string[];
  highlightsEn: string[];
  icon: string;
  serviceSheetNoticeFa?: string;
  serviceSheetNoticeEn?: string;
}

export interface TeamMember {
  id: string;
  nameFa: string;
  nameEn: string;
  roleFa: string;
  roleEn: string;
  bioFa: string;
  bioEn: string;
  specialtyFa: string;
  specialtyEn: string;
}
