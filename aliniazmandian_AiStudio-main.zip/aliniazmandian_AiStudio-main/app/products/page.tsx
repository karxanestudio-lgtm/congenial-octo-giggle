'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Language, Product } from '@/types';
import { Header } from '@/components/Header';
import { ProductSection } from '@/components/ProductSection';
import { Footer } from '@/components/Footer';
import { SettingsModal } from '@/components/SettingsModal';
import { ArrowRight, ArrowLeft, ShieldCheck, Camera, Phone, CheckCircle2, X } from 'lucide-react';

export default function ProductsPage() {
  const [lang, setLang] = useState<Language>('fa');
  const [isDark, setIsDark] = useState<boolean>(true);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [inquiryProduct, setInquiryProduct] = useState<Product | null>(null);
  const [inquirySubmitted, setInquirySubmitted] = useState(false);
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');

  // Sync document language and text direction
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  }, [lang]);

  // Sync dark theme class on document
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      document.body.style.backgroundColor = '#0D0D0D';
      document.body.style.color = '#FFFFFF';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.style.backgroundColor = '#FAFAFA';
      document.body.style.color = '#0D0D0D';
    }
  }, [isDark]);

  const handleSelectProductForInquiry = (product: Product) => {
    setInquiryProduct(product);
    setInquirySubmitted(false);
  };

  const handleSendInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    setInquirySubmitted(true);
  };

  const isRtl = lang === 'fa';

  return (
    <div
      id="products-page-root"
      suppressHydrationWarning
      className={`min-h-screen relative transition-colors duration-300 ${
        isDark ? 'bg-[#0D0D0D] text-white' : 'bg-[#FAFAFA] text-[#0D0D0D]'
      }`}
    >
      {/* Fixed Sticky Header */}
      <Header
        lang={lang}
        isDark={isDark}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Content */}
      <main className="relative z-10 pt-24 pb-12">
        {/* Dedicated Product Showcase Section */}
        <ProductSection
          lang={lang}
          isDark={isDark}
          onSelectProductForInquiry={handleSelectProductForInquiry}
        />

        {/* Reassurance Hub & Back to Home Banner (Placed at the bottom before footer as requested) */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 mb-4">
          <div
            className={`flex flex-col md:flex-row items-center justify-between gap-6 p-6 sm:p-8 rounded-2xl border backdrop-blur-md transition-all ${
              isDark
                ? 'bg-neutral-900/60 border-neutral-800 text-neutral-200'
                : 'bg-white/90 border-neutral-200 text-neutral-800 shadow-sm'
            }`}
          >
            {/* Guarantee and Sirang Service Info */}
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-[#ee2524]/10 text-[#ee2524] shrink-0 mt-0.5">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base sm:text-lg mb-1">
                  {isRtl
                    ? 'اصالت، سلامت و ضمانت کتبی کارخانه'
                    : 'Authenticity, Bench-Tested & Written Guarantee'}
                </h4>
                <p
                  className={`text-xs sm:text-sm leading-relaxed max-w-xl ${
                    isDark ? 'text-neutral-400' : 'text-neutral-600'
                  }`}
                >
                  {isRtl
                    ? 'تمام تجهیزات دست‌دوم توسط متخصصین تعمیرخانه سیرنگ سرویس در شیراز عیب‌یابی، کالیبره و پلمب شده‌اند و همراه با برگه کارشناسی و مهلت تست فنی ارائه می‌شوند.'
                    : 'All pre-owned gear is ultrasonically cleaned, optical bench-calibrated and sealed by Sirang Service technicians in Shiraz with written technical test certificates.'}
                </p>
              </div>
            </div>

            {/* Back to Home Action */}
            <div className="flex items-center gap-3 shrink-0 w-full md:w-auto justify-end">
              <Link
                href="/"
                className="inline-flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold px-6 py-3 rounded-full bg-[#ee2524] text-white hover:bg-[#d41e1d] shadow-md hover:shadow-lg transition-all duration-150 cursor-pointer w-full md:w-auto"
              >
                {isRtl ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                <span>{isRtl ? 'بازگشت به صفحه اصلی استودیو' : 'Return to Studio Home'}</span>
              </Link>
            </div>
          </div>
        </div>
      </main>

      {/* Quick Inquiry Modal for Products */}
      {inquiryProduct && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
        >
          <div
            className={`relative w-full max-w-md rounded-2xl border p-6 shadow-2xl transition-all ${
              isDark ? 'bg-neutral-900 border-neutral-700 text-white' : 'bg-white border-neutral-300 text-neutral-900'
            }`}
          >
            <button
              onClick={() => setInquiryProduct(null)}
              className="absolute top-4 left-4 p-1.5 rounded-lg hover:bg-neutral-800/20 transition-colors text-neutral-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 mb-4">
              <div className="p-2 rounded-xl bg-[#ee2524]/10 text-[#ee2524]">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold">
                  {isRtl ? 'استعلام و رزرو تجهیزات' : 'Inquire & Reserve Gear'}
                </h3>
                <p className="text-xs text-[#ee2524] font-medium">
                  {isRtl ? inquiryProduct.name : inquiryProduct.nameEn}
                </p>
              </div>
            </div>

            {inquirySubmitted ? (
              <div className="py-6 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto" />
                <p className="font-bold text-sm">
                  {isRtl ? 'درخواست شما ثبت شد!' : 'Inquiry Submitted!'}
                </p>
                <p className="text-xs text-neutral-400 max-w-xs mx-auto leading-relaxed">
                  {isRtl
                    ? 'کارشناسان استودیو کارخانه در اسرع وقت جهت هماهنگی، تست حضوری و تحویل با شما تماس خواهند گرفت.'
                    : 'Our team will contact you shortly to arrange in-person inspection and delivery.'}
                </p>
                <button
                  onClick={() => setInquiryProduct(null)}
                  className="mt-4 px-6 py-2 rounded-xl bg-[#ee2524] text-white text-xs font-bold cursor-pointer hover:bg-[#d41f1e]"
                >
                  {isRtl ? 'بستن' : 'Close'}
                </button>
              </div>
            ) : (
              <form onSubmit={handleSendInquiry} className="space-y-4">
                <div className="p-3 rounded-xl bg-neutral-800/30 border border-neutral-700/40 text-xs space-y-1">
                  <div className="flex justify-between font-mono">
                    <span className="text-neutral-400">{isRtl ? 'شماره سریال/شناسه:' : 'Item Code:'}</span>
                    <span className="text-[#ee2524] font-bold">{inquiryProduct.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">{isRtl ? 'وضعیت سلامت:' : 'Condition:'}</span>
                    <span>{isRtl ? inquiryProduct.conditionFa : inquiryProduct.condition}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium mb-1">
                    {isRtl ? 'شماره تماس جهت هماهنگی' : 'Phone Number'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder={isRtl ? '۰۹۱۲۳۴۵۶۷۸۹' : '+98 912 345 6789'}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono transition-colors focus:outline-hidden focus:border-[#ee2524] ${
                      isDark ? 'bg-neutral-800/60 border-neutral-700 text-white' : 'bg-neutral-100 border-neutral-300 text-neutral-900'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium mb-1">
                    {isRtl ? 'توضیحات یا پرسش درباره قطعات و کالیبراسیون' : 'Notes / Inspection Questions'}
                  </label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder={isRtl ? 'آیا لنز همراه با هود و فیلتر تحویل داده می‌شود؟' : 'Any questions regarding lens accessories or tests...'}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs transition-colors focus:outline-hidden focus:border-[#ee2524] ${
                      isDark ? 'bg-neutral-800/60 border-neutral-700 text-white' : 'bg-neutral-100 border-neutral-300 text-neutral-900'
                    }`}
                  />
                </div>

                <div className="pt-2 flex items-center justify-between gap-3">
                  <a
                    href="tel:07136360000"
                    className="inline-flex items-center gap-1.5 text-xs text-[#ee2524] hover:underline"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{isRtl ? 'تماس فوری با کارگاه' : 'Call Workshop'}</span>
                  </a>

                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-[#ee2524] hover:bg-[#d41f1e] text-white text-xs font-bold transition-all shadow-md shadow-[#ee2524]/20 cursor-pointer"
                  >
                    {isRtl ? 'ارسال درخواست استعلام' : 'Submit Inquiry'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Comprehensive Footer */}
      <Footer
        lang={lang}
        isDark={isDark}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        lang={lang}
        isDark={isDark}
        onSetTheme={(val) => setIsDark(val)}
        onSetLang={(val) => setLang(val)}
      />
    </div>
  );
}
