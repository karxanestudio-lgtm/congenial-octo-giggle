import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Studio Karxane | استودیو کارخانه',
  description: 'مرکز تخصصی تصویر، تعمیرخانه، تاریکخانه، تأمین تجهیزات و کتابخانه عکاسی در شیراز - Specialized visual studio, camera service, darkroom, equipment and bookstore in Shiraz',
  openGraph: {
    title: 'Studio Karxane | استودیو کارخانه',
    description: 'مرکز تخصصی تصویر، تعمیرخانه، تاریکخانه، تأمین تجهیزات و کتابخانه عکاسی در شیراز - Specialized visual studio, camera service, darkroom, equipment and bookstore in Shiraz',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Studio Karxane | استودیو کارخانه',
    description: 'مرکز تخصصی تصویر، تعمیرخانه، تاریکخانه، تأمین تجهیزات و کتابخانه عکاسی در شیراز - Specialized visual studio, camera service, darkroom, equipment and bookstore in Shiraz',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <meta name="darkreader-lock" />
        <meta name="color-scheme" content="dark light" />
        <meta name="theme-color" content="#0D0D0D" />
      </head>
      <body className="min-h-screen bg-[#0D0D0D] text-white selection:bg-[#ee2524] selection:text-white transition-colors duration-300" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
