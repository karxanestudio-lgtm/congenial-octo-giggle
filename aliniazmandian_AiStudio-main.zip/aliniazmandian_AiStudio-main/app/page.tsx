'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Language, Department } from '@/types';
import { Header } from '@/components/Header';
import { GlobalExplodedCameraBackground } from '@/components/GlobalExplodedCameraBackground';
import { CameraExplodedHero } from '@/components/CameraExplodedHero';
import { DepartmentShowcase } from '@/components/DepartmentShowcase';
import { AboutSection } from '@/components/AboutSection';
import { ContactSection } from '@/components/ContactSection';
import { Footer } from '@/components/Footer';
import { SettingsModal } from '@/components/SettingsModal';
import { Camera, ArrowLeft, ArrowRight } from 'lucide-react';

export default function HomePage() {
  const router = useRouter();
  const [lang, setLang] = useState<Language>('fa');
  const [isDark, setIsDark] = useState<boolean>(true);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [prefilledGear, setPrefilledGear] = useState<string>('');
  const [prefilledService, setPrefilledService] = useState<string>('workshop');

  // Ensure landing page strictly starts at scroll 0 on every initial load without jumping
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if ('scrollRestoration' in window.history) {
        window.history.scrollRestoration = 'manual';
      }
      window.scrollTo(0, 0);

      // Extra safeguard against browser scroll restoration or autofocus elements
      const timer = setTimeout(() => {
        window.scrollTo(0, 0);
      }, 50);

      return () => clearTimeout(timer);
    }
  }, []);

  // Sync document language and text direction
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  }, [lang]);

  // Sync dark theme class on document
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      document.body.style.backgroundColor = '#0D0D0D';
      document.body.style.color = '#FFFFFF';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.style.backgroundColor = '#FAFAFA';
      document.body.style.color = '#0D0D0D';
    }
  }, [isDark]);

  const handleToggleLang = () => {
    setLang((prev) => (prev === 'fa' ? 'en' : 'fa'));
  };

  const handleToggleTheme = () => {
    setIsDark((prev) => !prev);
  };

  const handleExploreGear = () => {
    router.push('/products');
  };

  const handleRequestConsultation = () => {
    setPrefilledService('repair');
    setPrefilledGear('');
    const el = document.getElementById('contact');
    if (el) {
      const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
      el.scrollIntoView({ behavior: isMobile ? 'auto' : 'smooth' });
    }
  };

  const handleRequestDepartmentService = (dept: Department) => {
    setPrefilledService(dept.id);
    setPrefilledGear('');
    const el = document.getElementById('contact');
    if (el) {
      const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
      el.scrollIntoView({ behavior: isMobile ? 'auto' : 'smooth' });
    }
  };

  return (
    <div
      id="app-root"
      suppressHydrationWarning
      className={`min-h-screen relative transition-colors duration-300 ${
        isDark ? 'bg-[#0D0D0D] text-white' : 'bg-[#FAFAFA] text-[#0D0D0D]'
      }`}
    >
      {/* Global Exploded CAD Camera Background (fixed in viewport, animates on scroll) */}
      <GlobalExplodedCameraBackground isDark={isDark} />

      {/* Fixed Sticky Header */}
      <Header
        lang={lang}
        isDark={isDark}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="relative z-10">
        {/* 1. Hero Section with Camera Exploded View & Scroll Reactivity */}
        <CameraExplodedHero isDark={isDark} />

        {/* 2. The Four Pillars of Karxane (تعمیرخانه، تاریکخانه، کارخانه، کتابخانه) */}
        <DepartmentShowcase
          lang={lang}
          isDark={isDark}
          onRequestDepartmentService={handleRequestDepartmentService}
        />

        {/* Dedicated CTA Banner & Button to Products Showcase Page */}
        <section
          className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 mb-16"
        >
          <div
            className={`p-6 sm:p-8 md:p-10 rounded-3xl border transition-all flex flex-col md:flex-row items-center justify-between gap-6 md:backdrop-blur-md ${
              isDark
                ? 'bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-neutral-950 border-white/15 shadow-2xl shadow-black/50'
                : 'bg-gradient-to-r from-white via-neutral-100 to-neutral-200/90 border-neutral-300/80 shadow-xl shadow-neutral-300/40 text-[#0D0D0D]'
            }`}
          >
            <div className="space-y-2 text-center md:text-start">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-medium text-[#ee2524] bg-[#ee2524]/10 border border-[#ee2524]/20">
                <Camera className="w-3.5 h-3.5" />
                <span>{lang === 'fa' ? 'ویترین تخصصی فضای کارخانه' : 'Equipment Hub Showcase'}</span>
              </div>
              <h3 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight">
                {lang === 'fa' ? 'کاوش در ویترین دوربین‌ها و تجهیزات کارخانه' : 'Explore Certified Cameras & Optical Gear'}
              </h3>
              <p className={`text-xs sm:text-sm max-w-xl leading-relaxed ${isDark ? 'text-neutral-400' : 'text-neutral-600'}`}>
                {lang === 'fa'
                  ? 'مشاهده مشخصات فنی، تست سنسور، کارکرد شاتر و امکان استعلام انواع دوربین‌های آنالوگ، دیجیتال و لنزهای تخصصی با ۳ ماه ضمانت کتبی سیرنگ سرویس.'
                  : 'Browse technical test sheets, shutter actuations, sensor inspections, and reserve analog and digital cameras with 3-month written warranty.'}
              </p>
            </div>

            <Link
              href="/products"
              className="inline-flex items-center gap-3 px-7 py-4 rounded-2xl bg-[#ee2524] hover:bg-[#d41f1e] text-white font-bold text-sm transition-all duration-200 shadow-lg shadow-[#ee2524]/30 hover:scale-[1.02] active:scale-95 shrink-0 group cursor-pointer"
            >
              <Camera className="w-5 h-5 text-white transition-transform group-hover:rotate-12" />
              <span>{lang === 'fa' ? 'مشاهده صفحه محصولات' : 'Go to Products Page'}</span>
              {lang === 'fa' ? (
                <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
              ) : (
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              )}
            </Link>
          </div>
        </section>

        {/* 3. About Us Page/Section (Brand Story from Shiraz 1405 + Expert Team) */}
        <AboutSection
          lang={lang}
          isDark={isDark}
        />

        {/* 4. Contact Section with Practical Form & Shiraz Workshop Info */}
        <ContactSection
          lang={lang}
          isDark={isDark}
          prefilledGear={prefilledGear}
          prefilledService={prefilledService}
        />
      </main>

      {/* 6. Comprehensive Footer with Quick Links */}
      <Footer
        lang={lang}
        isDark={isDark}
      />

      {/* 7. Settings Modal (Dark/Light Mode & Language Configuration) */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        lang={lang}
        isDark={isDark}
        onSetTheme={(val) => setIsDark(val)}
        onSetLang={(val) => setLang(val)}
      />
    </div>
  );
}
