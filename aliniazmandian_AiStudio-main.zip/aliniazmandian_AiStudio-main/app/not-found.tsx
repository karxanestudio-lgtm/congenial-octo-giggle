import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0D0D0D] text-white p-4 text-center">
      <h1 className="text-4xl font-bold text-[#ee2524] mb-2">۴۰۴</h1>
      <p className="text-sm text-neutral-400 mb-6">صفحه مورد نظر یافت نشد | Page Not Found</p>
      <Link
        href="/"
        className="px-6 py-2.5 rounded-full bg-[#ee2524] text-white text-xs font-semibold hover:bg-[#d41f1e] transition-colors"
      >
        بازگشت به صفحه اصلی
      </Link>
    </div>
  );
}
